﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace SampleDataGen
{
    class Program
    {
        #region Configuration
        private static string connStr;
        private static string containerName;
        private static int numberOfEventPackages;
        private static int sleepInterval;
        private static int minEventsPerPackage;
        private static int maxEventsPerPackage;
        private static int anomalyMultiplier;
        private static double anomalyProbability;

        private static void LoadConfiguration()
        {
            connStr = System.Configuration.ConfigurationManager.AppSettings["blobConnectionString"];
            containerName = System.Configuration.ConfigurationManager.AppSettings["containerName"];
            numberOfEventPackages = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["numberOfEventPackages"]);
            sleepInterval = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["sleepInterval"]);
            minEventsPerPackage = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["minEventsPerPackage"]);
            maxEventsPerPackage = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["maxEventsPerPackage"]);
            anomalyMultiplier = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["anomalyMultiplier"]);
            anomalyProbability = Double.Parse(System.Configuration.ConfigurationManager.AppSettings["anomalyProbability"]);
        }
        #endregion

        static void Main(string[] args)
        {
            LoadConfiguration();

            for (int i = 0; i < numberOfEventPackages; i++)
            {
                Console.Write("Sending event package #{0}...", i+1);
                WriteToBlob(GenerateText());
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Done!");
                Console.ForegroundColor = ConsoleColor.Gray;
                Thread.Sleep(sleepInterval);
            }            
        }

        private static void WriteToBlob(string text)
        {            
            // Retrieve storage account from connection string.
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connStr);

            // Create the blob client.
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

            // Retrieve reference to a previously created container.
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);

            // Retrieve reference to a blob.
            CloudBlockBlob blockBlob = container.GetBlockBlobReference(GetBlobName());

            blockBlob.UploadText(text);
        }

        private static string GetBlobName()
        {
            StringBuilder sb = new StringBuilder();
            var timeNow = DateTime.Now;
            sb.Append(timeNow.ToString(@"yyyy\/MM\/dd\/HH\/"));
            sb.Append("IncomingData_");
            sb.Append(timeNow.ToString("yyyyMMddHHmmssfff"));
            sb.Append(".csv");
            return sb.ToString();
        }

        private static string GenerateText()
        {
            #region Sentences
            string[] sentences =
            {
                    "He turned in the research paper on Friday; otherwise  he would have not passed the class.",
                    "The body may perhaps compensates for the loss of a true metaphysics.",
                    "Malls are great places to shop; I can find everything I need under one roof.",
                    "Check back tomorrow; I will see if the book has arrived.",
                    "She did not cheat on the test  for it was not the right thing to do.",
                    "The stranger officiates the meal.",
                    "If I don’t like something  I’ll stay away from it.",
                    "The lake is a long way from here.",
                    "Don't step on the broken glass.",
                    "I am happy to take your donation; any amount will be greatly appreciated.",
                    "He told us a very exciting adventure story.",
                    "I want to buy a onesie… but know it won’t suit me.",
                    "Last Friday in three week’s time I saw a spotted striped blue worm shake hands with a legless lizard.",
                    "We have never been to Asia  nor have we visited Africa.",
                    "She wrote him a long letter  but he didn't read it.",
                    "It was getting dark  and we weren’t there yet.",
                    "She was too short to see over the fence.",
                    "I hear that Nancy is very pretty.",
                    "If the Easter Bunny and the Tooth Fairy had babies would they take your teeth and leave chocolate for you?",
                    "She always speaks to him in a loud voice.",
                    "Should we start class now  or should we wait for everyone to get here?",
                    "I am counting my calories  yet I really want dessert.",
                    "Abstraction is often one floor above you.",
                    "Hurry!",
                    "If Purple People Eaters are real… where do they find purple people to eat?",
                    "Please wait outside of the house.",
                    "This is the last random sentence I will be writing and I am going to stop mid-sent",
                    "When I was little I had a car door slammed shut on my hand. I still remember it quite vividly.",
                    "The book is in front of the table.",
                    "I will never be this young again. Ever. Oh damn… I just got older.",
                    "Lets all be unique together until we realise we are all the same.",
                    "The old apple revels in its authority.",
                    "I think I will buy the red car  or I will lease the blue one.",
                    "We need to rent a room for our party.",
                    "I checked to make sure that he was still alive.",
                    "The clock within this blog and the clock on my laptop are 1 hour different from each other.",
                    "The waves were crashing on the shore; it was a lovely sight.",
                    "My Mum tries to be cool by saying that she likes all the same things that I do.",
                    "How was the math test?",
                    "Two seats were vacant.",
                    "The memory we used to share is no longer coherent.",
                    "She only paints with bold colors; she does not like pastels.",
                    "She folded her handkerchief neatly.",
                    "Wow  does that work?",
                    "Christmas is coming.",
                    "They got there early  and they got really good seats.",
                    "What was the person thinking when they discovered cow’s milk was fine for human consumption… and why did they do it in the first place!?",
                    "Someone I know recently combined Maple Syrup & buttered Popcorn thinking it would taste like caramel popcorn. It didn’t and they don’t recommend anyone else do it either.",
                    "I was very proud of my nickname throughout high school but today- I couldn’t be any different to what my nickname was.",
                    "The shooter says goodbye to his love.",
                    "We have a lot of rain in June.",
                    "Sometimes  all you need to do is completely make an ass of yourself and laugh it off to realise that life isn’t so bad after all.",
                    "Sometimes it is better to just walk away from things and go back to them later when you’re in a better frame of mind.",
                    "If you like tuna and tomato sauce- try combining the two. It’s really not as bad as it sounds.",
                    "She borrowed the book from him many years ago and hasn't yet returned it.",
                    "I would have gotten the promotion  but my attendance wasn’t good enough.",
                    "I currently have 4 windows open up… and I don’t know why.",
                    "She did her best to help him.",
                    "Is it free?",
                    "Tom got a small piece of pie.",
                    "Joe made the sugar cookies; Susan decorated them.",
                    "He said he was not there yesterday; however  many people saw him there.",
                    "Italy is my favorite country; in fact  I plan to spend two weeks there next year.",
                    "Let me help you with your baggage.",
                    "The mysterious diary records the voice.",
                    "There was no ice cream in the freezer  nor did they have money to go to the store.",
                    "A glittering gem is not enough.",
                    "I love eating toasted cheese and tuna sandwiches.",
                    "He ran out of money  so he had to stop playing poker.",
                    "Rock music approaches at high velocity.",
                    "She works two jobs to make ends meet; at least  that was her reason for not having time to join us.",
                    "Wednesday is hump day  but has anyone asked the camel if he’s happy about it?",
                    "This is a Japanese doll.",
                    "I am never at home on Sundays.",
                    "Everyone was busy  so I went to the movie alone.",
                    "Where do random thoughts come from?",
                    "She advised him to come back at once.",
                    "Cats are good pets  for they are clean and are not noisy.",
                    "The quick brown fox jumps over the lazy dog.",
                    "Sixty-Four comes asking for bread.",
                    "He didn’t want to go to the dentist  yet he went anyway.",
                    "A song can make or ruin a person’s day if they let it get to them.",
                    "I want more detailed information.",
                    "I'd rather be a bird than a fish.",
                    "A purple pig and a green donkey flew a kite in the middle of the night and ended up sunburnt.",
                    "The river stole the gods.",
                    "Yeah  I think it's a good environment for learning English.",
                    "The sky is clear; the stars are twinkling.",
                    "Mary plays the piano.",
                    "There were white out conditions in the town; subsequently  the roads were impassable.",
                    "Writing a list of random sentences is harder than I initially thought it would be.",
                    "I really want to go to work  but I am too sick to drive.",
                    "I often see the time 11:11 or 12:34 on clocks."
            };
            #endregion

            StringBuilder sb = new StringBuilder();
            Random rand = new Random();

            sb.AppendLine("text");

            int j = (int)(rand.NextDouble() * maxEventsPerPackage) + 1;

            if (rand.NextDouble() <= anomalyProbability)
            {
                j += maxEventsPerPackage * anomalyMultiplier;
            }

            for (int i = 0; i < j; i++)
            {
                var sentence = sentences[(int)(rand.NextDouble() * sentences.Count())];
                sb.AppendLine(sentence);
            }

            return sb.ToString();
        }
    }
}
