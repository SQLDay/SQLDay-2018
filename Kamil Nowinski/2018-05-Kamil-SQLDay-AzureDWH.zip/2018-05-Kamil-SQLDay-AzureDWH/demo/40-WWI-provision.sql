
--Connect to server sqlplayer

CREATE DATABASE WWI
(EDITION = 'datawarehouse', SERVICE_OBJECTIVE='DW100');  --Gen1
GO


