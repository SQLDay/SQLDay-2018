USE AdventureWorks;
GO

--DBCC TRACEON(3604, -1)

--SET STATISTICS XML ON
--GO

SELECT * FROM Production.Product
OPTION (RECOMPILE);
GO









SELECT TOP(10) c.CustomerID, p.FirstName + ' ' + p.LastName AS FullName, SUM(sod.OrderQty * sod.UnitPrice) AS Overall
FROM Sales.Customer c
JOIN Sales.SalesOrderHeader soh
ON c.CustomerID = soh.CustomerID
JOIN Sales.SalesOrderDetail sod
ON soh.SalesOrderID = sod.SalesOrderID
JOIN Person.Person p
ON c.PersonID = p.BusinessEntityID
--WHERE c.CustomerID = 29818
GROUP BY c.CustomerID, p.FirstName + ' ' + p.LastName
HAVING SUM(sod.OrderQty * sod.UnitPrice) > 800000
ORDER BY Overall DESC
OPTION (RECOMPILE);
GO









SELECT p.Name, sod.OrderQty, sod.UnitPrice
FROM Production.Product AS p
JOIN Sales.SalesOrderDetail AS sod
ON p.ProductID = sod.ProductID
ORDER BY p.Name DESC
OPTION (RECOMPILE);
GO


--SET STATISTICS XML OFF
--GO








--Numbers of rows read
select FirstName, LastName 
  from Person.Person 
  where LastName = 'Smith' 
  and FirstName like 'J%';



select FirstName, LastName 
  from Person.Person
  where LastName like 'S%'
  and FirstName = 'John'; 
 



-- EstimateRowsWithoutRowGoal
SELECT TOP (100) *
FROM Sales.SalesOrderHeader AS s 
    INNER JOIN Sales.SalesOrderDetail AS d ON s.SalesOrderID = d.SalesOrderID
WHERE s.TotalDue > 1000
OPTION (RECOMPILE);
GO