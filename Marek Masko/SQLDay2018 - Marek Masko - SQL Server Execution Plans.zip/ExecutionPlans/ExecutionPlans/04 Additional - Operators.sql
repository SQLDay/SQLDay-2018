USE AdventureWorks;
GO

/****** Sort ******/
SELECT * FROM Production.Product
ORDER BY Name










/****** Stream Aggregate ******/
SELECT sod.SalesOrderID, SUM(sod.OrderQty * sod.UnitPrice) AS Overall
FROM Sales.SalesOrderDetail sod
GROUP BY sod.SalesOrderID










/****** Hash Aggregate ******/
SELECT SalesOrderHeader.TerritoryID, COUNT(*) as [Count]
FROM Sales.SalesOrderHeader
GROUP BY SalesOrderHeader.TerritoryID