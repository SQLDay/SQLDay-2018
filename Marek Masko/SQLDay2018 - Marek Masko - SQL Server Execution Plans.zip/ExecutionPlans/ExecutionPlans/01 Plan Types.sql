USE AdventureWorks;
GO


/****** Graphic plan ******/
SELECT TOP(1) p.Title+' '+p.FirstName+' '+p.LastName AS FullName, 
c.AccountNumber, s.Name
FROM Person.Person p
JOIN Sales.Customer c
ON c.PersonID=p.BusinessEntityID
JOIN Sales.Store s
ON s.BusinessEntityID=c.StoreID
WHERE p.LastName='Koski';
GO










/****** Estimated Text plan ******/
SET SHOWPLAN_TEXT ON
GO

SELECT TOP(1) p.Title+' '+p.FirstName+' '+p.LastName AS FullName, 
c.AccountNumber, s.Name
FROM Person.Person p
JOIN Sales.Customer c
ON c.PersonID=p.BusinessEntityID
JOIN Sales.Store s
ON s.BusinessEntityID=c.StoreID
WHERE p.LastName='Koski';
GO

SET SHOWPLAN_TEXT OFF
GO










/****** Estimated Text Plan (More data) ******/
SET SHOWPLAN_ALL ON
GO

SELECT TOP(1) p.Title+' '+p.FirstName+' '+p.LastName AS FullName, 
c.AccountNumber, s.Name
FROM Person.Person p
JOIN Sales.Customer c
ON c.PersonID=p.BusinessEntityID
JOIN Sales.Store s
ON s.BusinessEntityID=c.StoreID
WHERE p.LastName='Koski';
GO

SET SHOWPLAN_ALL OFF
GO










/****** Actual Text plan ******/
SET STATISTICS PROFILE ON
GO

SELECT TOP(1) p.Title+' '+p.FirstName+' '+p.LastName AS FullName, 
c.AccountNumber, s.Name
FROM Person.Person p
JOIN Sales.Customer c
ON c.PersonID=p.BusinessEntityID
JOIN Sales.Store s
ON s.BusinessEntityID=c.StoreID
WHERE p.LastName='Koski';
GO

SET STATISTICS PROFILE OFF
GO










/****** Estimated XML plan *******/
SET SHOWPLAN_XML ON
GO

SELECT TOP(1) p.Title+' '+p.FirstName+' '+p.LastName AS FullName, 
c.AccountNumber, s.Name
FROM Person.Person p
JOIN Sales.Customer c
ON c.PersonID=p.BusinessEntityID
JOIN Sales.Store s
ON s.BusinessEntityID=c.StoreID
WHERE p.LastName='Koski';
GO

SET SHOWPLAN_XML OFF
GO










/****** Actual XML plan ******/
SET STATISTICS XML ON
GO

SELECT TOP(1) p.Title+' '+p.FirstName+' '+p.LastName AS FullName, 
c.AccountNumber, s.Name
FROM Person.Person p
JOIN Sales.Customer c
ON c.PersonID=p.BusinessEntityID
JOIN Sales.Store s
ON s.BusinessEntityID=c.StoreID
WHERE p.LastName='Koski';
GO

SET STATISTICS XML OFF
GO










/*
 * You can request that SQL Server display ESTIMATED plans 
 * without executing the query with any of the following options:
 * SET SHOWPLAN_TEXT ON
 * SET SHOWPLAN_ALL ON
 * SET SHOWPLAN_XML ON
 * For graphical estimated plans, you can use:
 * Query | Display Estimated Execution Plan menu option. 
 * This can be invoked with a toolbar button, or with Cntl-L.
 */
 
/*
 * You can request that SQL Server display actual plans 
 * with any of the following options:
 * SET STATISTICS PROFILE ON
 * SET STATISTICS XML ON
 * For graphical actual plans, you can use:
 * Query | Include Actual Execution Plan menu option. 
 * This can be invoked with a toolbar button, or with Cntl-M.
 */ 