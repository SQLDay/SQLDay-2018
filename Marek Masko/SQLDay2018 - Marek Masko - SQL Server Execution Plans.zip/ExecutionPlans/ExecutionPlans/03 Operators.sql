USE AdventureWorks;
GO

/****** Table Scan ******/
SELECT * FROM Production.ProductProductPhoto










/****** Clustered Index Scan ******/
SELECT * FROM Production.Product










/****** Clustered Index Seek ******/
SELECT * FROM Production.Product
WHERE ProductID = 941










/****** (NonClustered) Index Scan ******/
SELECT ProductId, Name FROM Production.Product










/****** (NonClustered) Index Seek ******/
SELECT Name FROM Production.Product
WHERE Name LIKE 'Touring%'










/****** Key Lookup ******/
SELECT * FROM Production.Product
WHERE ProductNumber = 'BK-T79Y-54'










/****** RID Lookup ******/
SELECT * FROM dbo.DatabaseLog
WHERE DatabaseLogId = '17'










/****** Nested Loops Join ******/
SELECT soh.OrderDate, sod.OrderQty, sod.ProductID, sod.UnitPrice
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.SalesOrderDetail AS sod
ON soh.SalesOrderID = sod.SalesOrderID
WHERE soh.OrderDate BETWEEN '2014-05-17' AND '2014-05-18'










/****** Merge Join ******/
SELECT c.CustomerID, soh.SalesOrderID
FROM Sales.SalesOrderHeader AS soh
JOIN Sales.Customer AS c
ON soh.CustomerID = c.CustomerID










/****** Hash Match ******/
SELECT p.Name As ProductName, ps.Name As ProductSubcategoryName
FROM Production.Product p
JOIN Production.ProductSubcategory ps
ON p.ProductSubcategoryID = ps.ProductSubcategoryID






