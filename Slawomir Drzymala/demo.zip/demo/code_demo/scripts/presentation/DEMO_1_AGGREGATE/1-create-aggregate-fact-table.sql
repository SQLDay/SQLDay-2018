-- add table key
alter table [dbo].[FactInternetSales]
add [InternetSalesID] int





-- generate "fake" id
;with cte as
(
select 
		[ProductKey]
		, [OrderDateKey]
		, [DueDateKey]
		, [ShipDateKey]
		, [CustomerKey]
		, [PromotionKey]
		, [CurrencyKey]
		, [SalesTerritoryKey]
		,[InternetSalesID_Generate] = RANK() OVER(ORDER BY [ProductKey], [OrderDateKey], [DueDateKey], [ShipDateKey], [CustomerKey], [PromotionKey], [CurrencyKey], [SalesTerritoryKey])
from [dbo].[FactInternetSales]
)
update trg
set trg.[InternetSalesID] = src.[InternetSalesID_Generate]
from cte src
inner join [dbo].[FactInternetSales] trg
	on
	src.[ProductKey]			=	trg.[ProductKey]
	AND src.[OrderDateKey]			=	trg.[OrderDateKey]
	AND src.[DueDateKey]			=	trg.[DueDateKey]
	AND src.[ShipDateKey]			=	trg.[ShipDateKey]
	AND src.[CustomerKey]			=	trg.[CustomerKey]
	AND src.[PromotionKey]			=	trg.[PromotionKey]
	AND src.[CurrencyKey]			=	trg.[CurrencyKey]
	AND src.[SalesTerritoryKey]		=	trg.[SalesTerritoryKey]





-- create preagregated fact table view
if exists(select 1 from sys.views where name='FactInternetSales_Aggregate' and type='v') drop view [dbo].[FactInternetSales_Aggregate]

go

CREATE VIEW [dbo].[FactInternetSales_Aggregate]
AS
select 
	[ProductKey]
	, [OrderDateKey]
	, [DueDateKey]
	, [ShipDateKey]
	, [CustomerKey]
	, [PromotionKey]
	, [CurrencyKey]
	, [SalesTerritoryKey]
	--, [SalesOrderNumber]
	--, [SalesOrderLineNumber]
	--, [RevisionNumber]
	, [OrderQuantity]									=	SUM([OrderQuantity])
	, [UnitPrice]										=	SUM([UnitPrice])
	, [ExtendedAmount]									=	SUM([ExtendedAmount])
	, [UnitPriceDiscountPct]							=	SUM([UnitPriceDiscountPct])
	, [DiscountAmount]									=	SUM([DiscountAmount])
	, [ProductStandardCost]								=	SUM([ProductStandardCost])
	, [TotalProductCost]								=	SUM([TotalProductCost])
	, [SalesAmount]										=	SUM([SalesAmount])
	, [TaxAmt]											=	SUM([TaxAmt])
	, [Freight]											=	SUM([Freight])
	--, [CarrierTrackingNumber]
	--, [CustomerPONumber]
	--, [OrderDate]
	--, [DueDate]
	--, [ShipDate]
	, [InternetSalesID]
from [dbo].[FactInternetSales]
group by 
[ProductKey]
	, [OrderDateKey]
	, [DueDateKey]
	, [ShipDateKey]
	, [CustomerKey]
	, [PromotionKey]
	, [CurrencyKey]
	, [SalesTerritoryKey]
	, [InternetSalesID]







-- check
select count(*) from [dbo].[FactInternetSales_Aggregate]
select count(*) from [dbo].[FactInternetSales]











-- create preagregated fact table details view
if exists(select 1 from sys.views where name='FactInternetSales_AggregateDetails' and type='v') drop view [dbo].[FactInternetSales_AggregateDetails]

go

CREATE VIEW [dbo].[FactInternetSales_AggregateDetails]
AS
select 
	[InternetSalesID]
	, [SalesOrderNumber]
	, [SalesOrderLineNumber]
	, [RevisionNumber]									
	, [CarrierTrackingNumber]
	, [CustomerPONumber]
from [dbo].[FactInternetSales]







drop view [dbo].[FactInternetSales_Aggregate_FactInternetSales]

create view [dbo].[FactInternetSales_Aggregate_FactInternetSales]
as
select 
distinct 
[InternetSalesID]
, [SalesOrderNumber]
, [SalesOrderLineNumber]
from [dbo].[FactInternetSales]

