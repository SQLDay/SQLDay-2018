﻿



############# USER CONFIG #############

# log and configuration paths
$CIDirectory = "C:\code\ci\"
$CILogFileName = "CI_log_SSAS.txt"

# binaries paths
$DenvPath = "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\Common7\IDE\devenv.exe"
$DeploymentWizardPath = "C:\Program Files (x86)\Microsoft SQL Server\140\Tools\Binn\ManagementStudio\Microsoft.AnalysisServices.Deployment.exe"

# ssas solution configuration
$SSASSOlutionDirectory = "C:\code\adventure-works-multidimensional-model-project\Enterprise\AWDW2014Multidimensional-EE\bin\"
$SSASSolutionPath = "C:\code\adventure-works-multidimensional-model-project\Enterprise\AWDW2014Multidimensional-EE.sln"
$SSASDatabaseName = "AWDW2014Multidimensional-EE.asdatabase"
$SSASDeploymentSettingsFileName = "AWDW2014Multidimensional-EE.deploymentoptions"
$SSASDeployScriptFileName = "deploy.xmla"
$SSASServerName = "demo\ssasm"
$SSASDatabaseServerName = "AdventureWorksDW2014Multidimensional-EE"

# check the deployment duration
$CurrentDateTime = Get-Date
$ElapsedTimeSeconds = 0
$MaxElapsedTimeSeconds = 20
$isError = ""
$log = ""

# create folder for deployment artifacts
$NewFolderDateTimeName = ((Get-Date).ToString("yyyyMMdd") + "_" + (Get-Date).ToString("hhmmss"))

# take care of logs
$ErrorActionPreference="SilentlyContinue"
Stop-Transcript | out-null
$ErrorActionPreference = "Continue"
New-Item -ItemType directory -Path ($CIDirectory + $NewFolderDateTimeName)
Start-Transcript -path ($CIDirectory + $NewFolderDateTimeName + "\" + $CILogFileName) -append

















############# SCRIPT #############

# Build project using devenv.exe
Write-Host "`r`r`r"
Write-Host "Build project"
& $DenvPath $SSASSolutionPath /build






# wait till project will be builded
Write-Host "`r`r`r"
Write-Host "Build project - progress / wait"
while (
((Get-Item ($SSASSOlutionDirectory + $SSASDatabaseName)).LastWriteTime -lt $CurrentDateTime))
{
    Start-Sleep -Seconds 1

    $ElapsedTimeSeconds = $ElapsedTimeSeconds + 1

    if ($ElapsedTimeSeconds -gt $MaxElapsedTimeSeconds)
    {
        $isError = "Error. Build timeout"
        break;
    }   
}









# Wait couple more seconds so the database will be created, 
# in real world there will be a couple more lines
Write-Host "`r`r`r"
Write-Host "Wait 5 seconds for database script to be created"
Start-Sleep -Seconds 5








# Create deployment script
Write-Host "`r`r`r"
Write-Host "Create deployment script"
if ($isError -eq "")
{
    # Overwrite the config file, copy existing config file
    Write-Host "Overwrite the config file"
    Copy-Item ($CIDirectory + $SSASDeploymentSettingsFileName) ($SSASSOlutionDirectory + $SSASDeploymentSettingsFileName)

    # Create deployment scripts, use SSASDeploymentWizard
    Write-Host "Create deployment scripts"
    & $DeploymentWizardPath ($SSASSOlutionDirectory + $SSASDatabaseName) /s ("/o:" + $SSASSOlutionDirectory + $SSASDeployScriptFileName)
}
else
{
    Write-Host "Creating deployment script failed, because ssas database file was not ready."
}
















#Copy deployment artifacts
Write-Host "`r`r`r"
Write-Host "Copy deployment artifacts"
Copy-item -Force -Recurse -Verbose ($SSASSOlutionDirectory) -Destination (($CIDirectory + $NewFolderDateTimeName))














# Deploy SSAS Database
Write-Host "`r`r`r"
Write-Host "Deploy SSAS database"
Invoke-ASCmd -Server: ($SSASServerName) –InputFile: ($SSASSOlutionDirectory + $SSASDeployScriptFileName)


















Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
#[System.reflection.Assembly]::LoadWithPartialName("Microsoft.AnalysisServices")  

$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)

#Process all dimension
Write-Host "`r`r`r"
Write-Host "Process dimensions"
foreach ($db in $svr.Databases[$SSASDatabaseServerName])
{
    foreach ($dimension in $db.Dimensions)
    {
        if ($dimension.State -ne "Processed")
        {
            "Process dimension: " + $dimension.Name
            $dimension.Process([Microsoft.AnalysisServices.ProcessType]::ProcessFull);
        }
        
    }
}



#Process structure of the cube
#Write-Host "`r`r`r"
#Write-Host "Process structure cubes"
#foreach ($db in $svr.Databases[$SSASDatabaseServerName])
#{
#    foreach ($cube in $db.Cubes)
#    {
#        "Process structure cube: " + $cube.Name
#        $cube.Process([Microsoft.AnalysisServices.ProcessType]::ProcessStructure)
#    }
#}


#Process basic measure groups
Write-Host "`r`r`r"
Write-Host "Process measure groups"
foreach ($db in $svr.Databases[$SSASDatabaseServerName])
{
    
    foreach ($cube in $db.Cubes)
    {
        foreach ($mg in $cube.MeasureGroups)
        {
            if ($mg.State -ne "Processed")
            {
                "Process measue group: " + $mg.Name
                $mg.Process([Microsoft.AnalysisServices.ProcessType]::ProcessFull)
            }
             
        }
    }
}






Stop-Transcript