﻿Clear-Host;

Stop-Service -Name 'MSOLAP$SSASM1' -Force;
Stop-Service -Name 'MSOLAP$SSASM2' -Force;

invoke-expression -command "C:\code\scripts\presentation\DEMO_3_SCALING\robocopy_ssas.bat" > $null;

Start-Service -Name 'MSOLAP$SSASM1';
Start-Service -Name 'MSOLAP$SSASM2';
