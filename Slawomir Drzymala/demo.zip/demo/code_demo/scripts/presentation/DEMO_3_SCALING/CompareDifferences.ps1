﻿$SSAS1DataDir = "C:\Program Files\Microsoft SQL Server\MSAS14.SSASM1\OLAP\Data\"
$SSAS2DataDir = "C:\Program Files\Microsoft SQL Server\MSAS14.SSASM2\OLAP\Data\"


$fso = Get-ChildItem -Recurse -path $SSAS1DataDir
$fsoBU = Get-ChildItem -Recurse -path $SSAS2DataDir
Compare-Object -ReferenceObject $fso -DifferenceObject $fsoBU