﻿Clear-Host

$SSASDatabaseServerName = "AdventureWorksDW2014Multidimensional-EE"
$SSASServerName1 = "demo\ssasm1"
$SSASServerName2 = "demo\ssasm2"
$SSASCubeName = "Adventure Works"
$SSAS1DataDir = "C:\Program Files\Microsoft SQL Server\MSAS14.SSASM1\OLAP\Data\"
$SSAS2DataDir = "C:\Program Files\Microsoft SQL Server\MSAS14.SSASM2\OLAP\Data\"






# check first server processing state
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName1)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]
"Check: " + $svr.ConnectionString + "   >   " +  $db.Name + "   >   " + $cube.Name + "   >   " + $cube.State

# check second server processing state
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName2)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]
"Check: " + $svr.ConnectionString + "   >   " +  $db.Name + "   >   " + $cube.Name + "   >   " + $cube.State


Write-Host "SSASM no files: " @( Get-ChildItem -Recurse -File $SSAS1DataDir ).Count;
Write-Host "SSASM2 no files: "@( Get-ChildItem -Recurse -File $SSAS2DataDir ).Count;








# if needed process first server
$query_unprocess_cube = "

<Batch xmlns=""http://schemas.microsoft.com/analysisservices/2003/engine"">
  <Parallel>
    <Process xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:ddl2=""http://schemas.microsoft.com/analysisservices/2003/engine/2"" xmlns:ddl2_2=""http://schemas.microsoft.com/analysisservices/2003/engine/2/2"" xmlns:ddl100_100=""http://schemas.microsoft.com/analysisservices/2008/engine/100/100"" xmlns:ddl200=""http://schemas.microsoft.com/analysisservices/2010/engine/200"" xmlns:ddl200_200=""http://schemas.microsoft.com/analysisservices/2010/engine/200/200"" xmlns:ddl300=""http://schemas.microsoft.com/analysisservices/2011/engine/300"" xmlns:ddl300_300=""http://schemas.microsoft.com/analysisservices/2011/engine/300/300"" xmlns:ddl400=""http://schemas.microsoft.com/analysisservices/2012/engine/400"" xmlns:ddl400_400=""http://schemas.microsoft.com/analysisservices/2012/engine/400/400"" xmlns:ddl500=""http://schemas.microsoft.com/analysisservices/2013/engine/500"" xmlns:ddl500_500=""http://schemas.microsoft.com/analysisservices/2013/engine/500/500"">
      <Object>
        <DatabaseID>AdventureWorksDW2014Multidimensional-EE</DatabaseID>
      </Object>
      <Type>ProcessFull</Type>
      <WriteBackTableCreation>UseExisting</WriteBackTableCreation>
    </Process>
  </Parallel>
</Batch>

"
Write-Host ("Process full first server " + $SSASServerName + " ") -NoNewline
(Measure-Command { Invoke-ASCmd -Server:$SSASServerName1 -Database:$SSASDatabaseServerName -Query:$query_unprocess_cube}).TotalSeconds.ToString() + " seconds"








# make the second server unprocessed
$query_unprocess_cube = "

<Batch xmlns=""http://schemas.microsoft.com/analysisservices/2003/engine"">
  <Parallel>
    <Process xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:ddl2=""http://schemas.microsoft.com/analysisservices/2003/engine/2"" xmlns:ddl2_2=""http://schemas.microsoft.com/analysisservices/2003/engine/2/2"" xmlns:ddl100_100=""http://schemas.microsoft.com/analysisservices/2008/engine/100/100"" xmlns:ddl200=""http://schemas.microsoft.com/analysisservices/2010/engine/200"" xmlns:ddl200_200=""http://schemas.microsoft.com/analysisservices/2010/engine/200/200"" xmlns:ddl300=""http://schemas.microsoft.com/analysisservices/2011/engine/300"" xmlns:ddl300_300=""http://schemas.microsoft.com/analysisservices/2011/engine/300/300"" xmlns:ddl400=""http://schemas.microsoft.com/analysisservices/2012/engine/400"" xmlns:ddl400_400=""http://schemas.microsoft.com/analysisservices/2012/engine/400/400"" xmlns:ddl500=""http://schemas.microsoft.com/analysisservices/2013/engine/500"" xmlns:ddl500_500=""http://schemas.microsoft.com/analysisservices/2013/engine/500/500"">
      <Object>
        <DatabaseID>AdventureWorksDW2014Multidimensional-EE</DatabaseID>
        <CubeID>Adventure Works</CubeID>
      </Object>
      <Type>ProcessClear</Type>
      <WriteBackTableCreation>UseExisting</WriteBackTableCreation>
    </Process>
  </Parallel>
</Batch>

"
Write-Host ("Process clear cube on server " + $SSASServerName + " ") -NoNewline
(Measure-Command { Invoke-ASCmd -Server:$SSASServerName2 -Database:$SSASDatabaseServerName -Query:$query_unprocess_cube }).TotalSeconds.ToString() + " seconds"






























# check first server processing state
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName1)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]
"Check: " + $svr.ConnectionString + "   >   " +  $db.Name + "   >   " + $cube.Name + "   >   " + $cube.State

# check second server processing state
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName2)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]
"Check: " + $svr.ConnectionString + "   >   " +  $db.Name + "   >   " + $cube.Name + "   >   " + $cube.State


Write-Host "SSASM no files: " @( Get-ChildItem -Recurse -File $SSAS1DataDir ).Count;
Write-Host "SSASM2 no files: "@( Get-ChildItem -Recurse -File $SSAS2DataDir ).Count;












# run synchronization
$query_unprocess_cube = "


<Synchronize xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns=""http://schemas.microsoft.com/analysisservices/2003/engine"">
  <Source>
    <ConnectionString>Provider=MSOLAP.8;Data Source=demo\ssasm;Integrated Security=SSPI;Initial Catalog=AdventureWorksDW2014Multidimensional-EE</ConnectionString>
    <Object>
      <DatabaseID>AdventureWorksDW2014Multidimensional-EE</DatabaseID>
    </Object>
  </Source>
  <SynchronizeSecurity>CopyAll</SynchronizeSecurity>
  <ApplyCompression>true</ApplyCompression>
</Synchronize>

"

Write-Host ("Run synchronization from server 1 to server 2 " + $SSASServerName + " ") -NoNewline
(Measure-Command { Invoke-ASCmd -Server:$SSASServerName2 -Database:$SSASDatabaseServerName -Query:$query_unprocess_cube }).TotalSeconds.ToString() + " seconds"
















# check first server processing state
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName1)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]
"Check: " + $svr.ConnectionString + "   >   " +  $db.Name + "   >   " + $cube.Name + "   >   " + $cube.State

# check second server processing state
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName2)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]
"Check: " + $svr.ConnectionString + "   >   " +  $db.Name + "   >   " + $cube.Name + "   >   " + $cube.State


Write-Host "SSASM no files: " @( Get-ChildItem -Recurse -File $SSAS1DataDir ).Count;
Write-Host "SSASM2 no files: "@( Get-ChildItem -Recurse -File $SSAS2DataDir ).Count;





#NOTES

#whitepaper:
#A past disadvantage of this method is that it could take a long time to complete. For example, in one scenario, a 10‑GB
#database with about 250,000 files took around 11 hours to complete (if at all) in Analysis Services 2005. Using the same database and
#hardware on Analysis Services 2008 CTP5, the synchronization now takes around 40 minutes.