﻿Write-Host "SSASM1 no files: " @( Get-ChildItem -Recurse -File $SSAS1DataDir ).Count;
Write-Host "SSASM2 no files: "@( Get-ChildItem -Recurse -File $SSAS2DataDir ).Count;