﻿Clear-Host

$SSASDatabaseServerName = "AdventureWorksDW2014Multidimensional-EE"
$SSASServerName = "demo\ssasm"
$SSASCubeName = "Adventure Works"


Function fCheckProcessState{
Param ()
            Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
            $svr = new-Object Microsoft.AnalysisServices.Server
            $svr.Connect($SSASServerName)
            $db = $svr.Databases[$SSASDatabaseServerName]
            $cube = $db.Cubes[$SSASCubeName]


            # cube
            Write-Host (&{If($cube.State -eq "Processed") {"[X]"} Else {If($cube.State -eq "PartiallyProcessed") {"[*]"} Else {"[ ]"}}}), $cube.Name 
 
            # measure groups and partitions
            foreach ($mg in $cube.MeasureGroups)
            {
                Write-Host "`t", $mg.Name
                foreach($p in $mg.Partitions)
                {
                    Write-Host "`t`t", (&{If($p.State -eq "Processed") {"[X]"} Else {"[ ]"}}), $p.Name
                }
            }

            # Dimensions
            foreach ($dim in $db.Dimensions)
            {
                Write-Host (&{If($dim.State -eq "Processed") {"[X]"} Else {"[ ]"}}), $dim.Name
            }



}








# process full SSAS database
Write-Host "process full SSAS database"
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName].Process("ProcessFull")







# check process state
Write-Host "`n`n`n"
fCheckProcessState





# process clear product dimension
Write-Host "`n`n`n"
Write-Host "process clear product dimension"
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName]
$db.Dimensions["Dim Product"].Process("ProcessClear")




# check process state
Write-Host "`n`n`n"
fCheckProcessState




# process full product dimension
Write-Host "`n`n`n"
Write-Host "process full product dimension"
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName]
$db.Dimensions["Dim Product"].Process("ProcessFull")



# check process state
Write-Host "`n`n`n"
fCheckProcessState








# process structure cube
#Write-Host "`n`n`n"
#Write-Host "process structure cube"
#3Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
#$svr = new-Object Microsoft.AnalysisServices.Server
#$svr.Connect($SSASServerName)
#$db = $svr.Databases[$SSASDatabaseServerName]
#$db.Cubes[$SSASCubeName].Process("ProcessStructure")







# check process state
#Write-Host "`n`n`n"
#fCheckProcessState









# process first partition
Write-Host "`n`n`n"
Write-Host "process first partition"
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName]
# note: this is the mg id and partiton id, it is like that in adventure works :)
$db.Cubes[$SSASCubeName].MeasureGroups["Fact Internet Sales 1"].Partitions["Internet_Sales_2008"].Process("ProcessFull")







# check process state
Write-Host "`n`n`n"
fCheckProcessState







# process the rest partitions but one
Write-Host "`n`n`n"
Write-Host "process all the rest measure groups but one"
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]

# measure groups and partitions
foreach ($mg in $cube.MeasureGroups)
{
    foreach($p in $mg.Partitions)
    {
        if ($mg.Name -ne "Internet Orders")
        {
            $p.Process("ProcessFull")
        }
    }
}








# check process state
Write-Host "`n`n`n"
fCheckProcessState












# process last measure group
Write-Host "`n`n`n"
Write-Host "process last measure group"
Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName]
$cube = $db.Cubes[$SSASCubeName]

# measure groups and partitions
foreach ($mg in $cube.MeasureGroups)
{
    foreach($p in $mg.Partitions)
    {
        if ($mg.Name -eq "Internet Orders")
        {
            $p.Process("ProcessFull")
        }
    }
}








# check process state
Write-Host "`n`n`n"
fCheckProcessState

