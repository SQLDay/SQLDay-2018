﻿Add-DnsServerResourceRecordCName -Name "domain.cube" -HostNameAlias "192.168.1.1" -ZoneName "domain.local"


