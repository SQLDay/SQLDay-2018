﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AnalysisServices;
using System.Configuration;

namespace SSAS_SyncService
{
    internal class Helper
    {
        public string SSASConnectionString  { get; set; }


        public static bool CheckIfUserExistsInRole(Role role, string username)
        {
            // If the group has not been created yet, obviously the user is not in the role... The 
            // Security model needs to sync the whole group first...
            if (role == null) return false;

            foreach (RoleMember member in role.Members)
            {
                if (member.Name.ToLower() == username.ToLower())
                {
                    return true;
                }
            }

            return false;
        }



        public static UserPrincipal CheckIfUserExistsInDomain(string username)
        {
            // Search in the domain
            PrincipalContext ctx = new PrincipalContext(ContextType.Domain);

            // Search for user in question
            UserPrincipal user = UserPrincipal.FindByIdentity(ctx, username);

            // Only if found!
            if (user != null)
            {
                RoleMember r = new RoleMember(username, user.Sid.ToString());
            }
            else
            {
                throw new Exception("User not found!");
            }

            return user;
        }

        public static void DeleteRole(string roleName, string databaseName)
        {
            // Now that we know that the user exists - let's remove from role...
            Microsoft.AnalysisServices.Server objServer = new Server();
            
            objServer.Connect(ConfigurationManager.AppSettings["MartsCubeConnectionString"]);

            // Database name... We need to find and check if it exists...
            Microsoft.AnalysisServices.Database objDB = objServer.Databases.Find(databaseName);

            // If exists delete... 
            if (objDB.Roles.FindByName(roleName) != null)
            {
                // Get role..
                Role toDelete = objDB.Roles.GetByName(roleName);

                // Delete with all dependencies... We can also do a check on this...
                toDelete.Drop(DropOptions.AlterOrDeleteDependents);

                // Commit change!
                objDB.Update();
            }
        }


        public static void SyncDimensionPermission(DimensionPermission dimPermission, Dimension dimension, string roleId)
        {
            if (dimension.DimensionPermissions.GetByRole(roleId) == null)
            {
                dimPermission = dimension.DimensionPermissions.Add(roleId);
            }
            else
            {
                dimPermission = dimension.DimensionPermissions.GetByRole(roleId);
            }
        }


        public static void SyncDimensionPermissionAttributes(DimensionPermission permission, AttributePermission attributePermission)
        {
            // Clear if found... 
            if (permission.AttributePermissions.Find(attributePermission.AttributeID) != null)
            {
                permission.AttributePermissions.Clear();
                permission.Update(UpdateOptions.AlterDependents, UpdateMode.UpdateOrCreate);
            }

            // Recreate
            permission.AttributePermissions.Add(attributePermission);
            permission.Update(UpdateOptions.AlterDependents, UpdateMode.UpdateOrCreate);
        }


        public static void DropRole(Role toDelete, Database objDB, string cubeName)
        {
            //delete members from role
            if (toDelete.Members.Count > 0)
            {
                toDelete.Members.Clear();
                toDelete.Update();
            }
            //delete dimension permissions for the role
            foreach (Dimension dim in objDB.Dimensions)
            {
                DimensionPermission dimPermission = dim.DimensionPermissions.FindByRole(toDelete.ID);
                if (dimPermission != null)
                {
                    dimPermission.AttributePermissions.Clear();
                    dimPermission.Drop(DropOptions.AlterOrDeleteDependents);
                }
            }
            //delete cube permissions for the role
            CubePermission cubePermission = objDB.Cubes[cubeName].CubePermissions.FindByRole(toDelete.ID);
            if (cubePermission != null) cubePermission.Drop(DropOptions.AlterOrDeleteDependents);
            //delete database permissions for role
            DatabasePermission dbPermission = objDB.DatabasePermissions.FindByRole(toDelete.ID);
            if (dbPermission != null) dbPermission.Drop(DropOptions.AlterOrDeleteDependents);
            //dbPermission.Update();
            //finally delete role from database
            toDelete.Drop(DropOptions.AlterOrDeleteDependents);

            // Commit change!
            objDB.Update();
        }
    }
}

