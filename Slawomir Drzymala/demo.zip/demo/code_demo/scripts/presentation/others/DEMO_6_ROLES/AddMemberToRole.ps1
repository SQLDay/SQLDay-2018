﻿Clear-Host

$SSASDatabaseServerName = "AdventureWorksDW2014Multidimensional-EE-V3"
$SSASServerName = "demo\ssasm"
$SSASCubeName = "Adventure Works"
$NewSSASMemberName = "DOMAIN\olapuser2"


Add-Type -Path 'C:\Program Files (x86)\Microsoft SQL Server\130\SDK\Assemblies\Microsoft.AnalysisServices.dll'
$svr = new-Object Microsoft.AnalysisServices.Server
$svr.Connect($SSASServerName)
$db = $svr.Databases[$SSASDatabaseServerName]


$db.Roles["Role"].Members.Add("DOMAIN\olapuser1");
$db.Roles["Role"].Update();



# check current state
#foreach ($role in $db.Roles)
#{
#    foreach ($member in $role.Members)
#    {
#        $role.ID + " > " + $role.Name + " > " + $member.Sid + " > " + $member.Name
#    }
#}




