# SSAS disk usage

## Description
Description {PL}
http://pl.seequality.net/ssas-analiza-plikow-serwera-kostek/

Description {EN}
Not avaliable yet. Will be added soon.

## Installation
1. Adjust the paths in the PowerShell script
2. Run PowerShell script
3. Adjust the parameters in Power Bi report
4. Refresh Power BI report

Please check the post from the description to see details.
