# SSAS Object Activity

## Description
Description {PL}
http://pl.seequality.net/analiza-uzycia-poszczegolnych-obiektow-bazy-analitycznej-ssas/

Description {EN}
Not avaliable yet. Will be added soon.

## Installation
1. Open report
2. Adjust parameters
3. Refresh report

Please check the post from the description to see details.
