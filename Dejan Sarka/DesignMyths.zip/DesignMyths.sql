-- Desygn Myths

-- Alter table switch partition - DML or DDL?

SET NOCOUNT ON;
GO
USE tempdb;
GO
-- Drop object if they exist
IF OBJECT_ID('dbo.FactInternetSales','U') IS NOT NULL
  DROP TABLE dbo.FactInternetSales;
GO
IF OBJECT_ID('dbo.FactInternetSalesNew','U') IS NOT NULL
  DROP TABLE dbo.FactInternetSalesNew;
GO
IF OBJECT_ID('dbo.FactInternetSalesOld','U') IS NOT NULL
  DROP TABLE dbo.FactInternetSalesOld;
GO
IF EXISTS 
 (SELECT * FROM sys.partition_schemes
  WHERE name = 'PsInternetSalesYear')
  DROP PARTITION SCHEME PsInternetSalesYear;
GO
IF EXISTS 
 (SELECT * FROM sys.partition_functions
  WHERE name = 'PfInternetSalesYear')
  DROP PARTITION FUNCTION PfInternetSalesYear;
GO

-- Partitioning function
CREATE PARTITION FUNCTION PfInternetSalesYear (TINYINT)
AS RANGE LEFT FOR VALUES (1, 2, 3, 4, 5, 6, 7, 8, 9);
GO
-- Partition scheme
CREATE PARTITION SCHEME PsInternetSalesYear
AS PARTITION PfInternetSalesYear
ALL TO ([PRIMARY]);
GO

-- Create FactInternetSales with partitioning column
CREATE TABLE dbo.FactInternetSales
(
 PcInternetSalesYear TINYINT  NOT NULL,
 CustomerKey         INT      NOT NULL,
 ProductKey          INT      NOT NULL,
 DateKey             INT      NOT NULL,
 OrderQuantity       SMALLINT NOT NULL DEFAULT 0,
 SalesAmount         MONEY    NOT NULL DEFAULT 0,
 UnitPrice           MONEY    NOT NULL DEFAULT 0,
 DiscountAmount      FLOAT    NOT NULL DEFAULT 0
)
ON PsInternetSalesYear(PcInternetSalesYear);
GO
-- Load FactInternetSales years 2005, 2006 and 2007
INSERT INTO dbo.FactInternetSales
(PcInternetSalesYear, 
 CustomerKey, ProductKey, DateKey,
 OrderQuantity, SalesAmount,
 UnitPrice, DiscountAmount)
SELECT 
 CAST(SUBSTRING(CAST(FIS.OrderDateKey AS CHAR(8)), 3, 2)
      AS TINYINT)
  AS PcInternetSalesYear,
 FIS.CustomerKey, FIS.ProductKey, FIS.OrderDateKey,
 FIS.OrderQuantity, FIS.SalesAmount,
 FIS.UnitPrice, FIS.DiscountAmount
FROM AdventureWorksDW2012.dbo.FactInternetSales AS FIS 
WHERE 
 CAST(SUBSTRING(CAST(FIS.OrderDateKey AS CHAR(8)), 3, 2)
      AS TINYINT) < 8;
GO

-- New data table with a check constraint
CREATE TABLE dbo.FactInternetSalesNew
(
 PcInternetSalesYear TINYINT  NOT NULL
  CHECK (PcInternetSalesYear = 8),
 CustomerKey         INT      NOT NULL,
 ProductKey          INT      NOT NULL,
 DateKey             INT      NOT NULL,
 OrderQuantity       SMALLINT NOT NULL DEFAULT 0,
 SalesAmount         MONEY    NOT NULL DEFAULT 0,
 UnitPrice           MONEY    NOT NULL DEFAULT 0,
 DiscountAmount      FLOAT    NOT NULL DEFAULT 0
);
GO
-- Old data table
CREATE TABLE dbo.FactInternetSalesOld
(
 PcInternetSalesYear TINYINT  NOT NULL,
 CustomerKey         INT      NOT NULL,
 ProductKey          INT      NOT NULL,
 DateKey             INT      NOT NULL,
 OrderQuantity       SMALLINT NOT NULL DEFAULT 0,
 SalesAmount         MONEY    NOT NULL DEFAULT 0,
 UnitPrice           MONEY    NOT NULL DEFAULT 0,
 DiscountAmount      FLOAT    NOT NULL DEFAULT 0
);
GO

-- Load year 2008 to FactInternetSalesNew
INSERT INTO dbo.FactInternetSalesNew
(PcInternetSalesYear, 
 CustomerKey,ProductKey, DateKey,
 OrderQuantity, SalesAmount,
 UnitPrice, DiscountAmount)
SELECT 
 CAST(SUBSTRING(CAST(FIS.OrderDateKey AS CHAR(8)), 3, 2)
      AS TINYINT)
  AS PcInternetSalesYear,
 FIS.CustomerKey, FIS.ProductKey, FIS.OrderDateKey,
 FIS.OrderQuantity, FIS.SalesAmount,
 FIS.UnitPrice, FIS.DiscountAmount
FROM AdventureWorksDW2012.dbo.FactInternetSales AS FIS 
WHERE 
 CAST(SUBSTRING(CAST(FIS.OrderDateKey AS CHAR(8)), 3, 2)
      AS TINYINT) = 8;
GO

-- Check the data in all tables
PRINT 'FactInternetSales';
SELECT 
 $PARTITION.PfInternetSalesYear(PcInternetSalesYear)
  AS PartitionNumber,
 COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSales
GROUP BY
 $PARTITION.PfInternetSalesYear(PcInternetSalesYear);
PRINT 'FactInternetSalesNew';
SELECT COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSalesNew;
PRINT 'FactInternetSalesOld';
SELECT COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSalesOld;
PRINT 'All partitions of the FactInternetSales table';
SELECT partition_number
FROM sys.partitions
WHERE object_id = OBJECT_ID(N'FactInternetSales')
ORDER BY partition_number;
GO

-- Switch data from FactInternetSalesNew to FactInternetSales
ALTER TABLE dbo.FactInternetSalesNew
 SWITCH TO dbo.factInternetSales PARTITION 8;
GO

-- Check the data in all tables
PRINT 'FactInternetSales';
SELECT 
 $PARTITION.PfInternetSalesYear(PcInternetSalesYear)
  AS PartitionNumber,
 COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSales
GROUP BY
 $PARTITION.PfInternetSalesYear(PcInternetSalesYear);
PRINT 'FactInternetSalesNew';
SELECT COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSalesNew;
PRINT 'FactInternetSalesOld';
SELECT COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSalesOld;
GO

-- Switch data from FactInternetSale to FactInternetSalesOld
-- Use composable DML
INSERT INTO dbo.FactInternetSalesOld
  SELECT *
  FROM (DELETE FROM dbo.FactInternetSales
          OUTPUT deleted.*
        WHERE 
		  $PARTITION.PfInternetSalesYear(PcInternetSalesYear) = 5)
	    AS D;
GO

-- Check the data in all tables
PRINT 'FactInternetSales';
SELECT 
 $PARTITION.PfInternetSalesYear(PcInternetSalesYear)
  AS PartitionNumber,
 COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSales
GROUP BY
 $PARTITION.PfInternetSalesYear(PcInternetSalesYear);
PRINT 'FactInternetSalesNew';
SELECT COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSalesNew;
PRINT 'FactInternetSalesOld';
SELECT COUNT(*) AS NumberOfRows
FROM dbo.FactInternetSalesOld;
PRINT 'All partitions of the FactInternetSales table';
SELECT partition_number
FROM sys.partitions
WHERE object_id = OBJECT_ID(N'FactInternetSales')
ORDER BY partition_number;
GO

-- No changes of schema, just changes of data

-- Think set oriented - running totals
USE AdventureWorksDW2016;
GO
SET STATISTICS IO ON;
GO

-- Query with a self join
WITH InternetSalesGender AS
(
SELECT ISA.CustomerKey, C.Gender,
 ISA.SalesOrderNumber + 
  CAST(ISA.SalesOrderLineNumber AS CHAR(1)) AS OrderLineNumber,
 ISA.SalesAmount
FROM dbo.FactInternetSales AS ISA
 INNER JOIN dbo.DimCustomer AS C
    ON ISA.CustomerKey = C.CustomerKey
WHERE ISA.CustomerKey <= 11500
)
SELECT ISG1.Gender, ISG1.OrderLineNumber,
 MIN(ISG1.SalesAmount), SUM(ISG2.SalesAmount) AS RunningTotal
FROM InternetSalesGender AS ISG1
 INNER JOIN InternetSalesGender AS ISG2
  ON ISG1.Gender = ISG2.Gender
     AND ISG1.OrderLineNumber >= ISG2.OrderLineNumber 
GROUP BY ISG1.Gender, ISG1.OrderLineNumber
ORDER BY ISG1.Gender, ISG1.OrderLineNumber;

-- Query with a window function
WITH InternetSalesGender AS
(
SELECT ISA.CustomerKey, C.Gender,
 ISA.SalesOrderNumber + 
  CAST(ISA.SalesOrderLineNumber AS CHAR(1)) AS OrderLineNumber,
 ISA.SalesAmount
FROM dbo.FactInternetSales AS ISA
 INNER JOIN dbo.DimCustomer AS C
    ON ISA.CustomerKey = C.CustomerKey
WHERE ISA.CustomerKey <= 11500
)
SELECT ISG.Gender, ISG.OrderLineNumber, ISG.SalesAmount, 
 SUM(ISG.SalesAmount) 
   OVER(PARTITION BY ISG.Gender
        ORDER BY ISG.OrderLineNumber
        ROWS BETWEEN UNBOUNDED PRECEDING
                 AND CURRENT ROW) AS RunningTotal
FROM InternetSalesGender AS ISG
ORDER BY ISG.Gender, ISG.OrderLineNumber;
GO

SET STATISTICS IO OFF;
GO

-- Think set oriented - APPLY
USE AdventureWorksDW2016;
GO

-- Top 2 orders for customer 21768
DECLARE @cid AS INT;
SET @cid = 21768
SELECT TOP 2 f.SalesOrderNumber, f.SalesOrderLineNumber,
 f.ProductKey, f.OrderQuantity, f.SalesAmount
FROM dbo.FactInternetSales AS f
WHERE f.CustomerKey = @cid
ORDER BY f.SalesOrderNumber DESC, f.SalesOrderLineNumber DESC
GO

-- Top 2 orders for each customer
SELECT c.CustomerKey, c.LastName, c.FirstName,
 F.*
FROM dbo.DimCustomer AS c
CROSS APPLY
(
SELECT TOP 2 f.SalesOrderNumber, f.SalesOrderLineNumber,
 f.ProductKey, f.OrderQuantity, f.SalesAmount
FROM dbo.FactInternetSales AS f
WHERE f.CustomerKey = c.CustomerKey
ORDER BY f.SalesOrderNumber DESC, f.SalesOrderLineNumber DESC
) AS F
ORDER BY c.CustomerKey,
 F.SalesOrderNumber DESC, F.SalesOrderLineNumber DESC;
GO
