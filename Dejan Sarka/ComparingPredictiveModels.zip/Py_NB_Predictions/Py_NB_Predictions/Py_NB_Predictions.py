# Imports
import pyodbc;
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB

# Connect to AWDW
# AWDW system DSN created in advance
con = pyodbc.connect('DSN=AWDW;UID=RUser;PWD=Pa$$w0rd')

# Read data
query = """
SELECT CustomerKey, MaritalStatus, Gender,
 TotalChildren, NumberChildrenAtHome,
 Education, Occupation,
 HouseOwnerFlag, NumberCarsOwned, CommuteDistance,
 Region, TrainTest, BikeBuyer
FROM dbo.TMTrain
UNION
 SELECT CustomerKey, MaritalStatus, Gender,
 TotalChildren, NumberChildrenAtHome,
 Education, Occupation,
 HouseOwnerFlag, NumberCarsOwned, CommuteDistance,
 Region, TrainTest, BikeBuyer
FROM dbo.TMTest;
"""
TM = pd.read_sql(query, con)
TM.head(5)
TM.shape

# Naive Bayes
# Arrange the data - feature matrix and target vector
# Split the data
Xtrain = TM.loc[TM.TrainTest == 1,
               ['TotalChildren', 'NumberChildrenAtHome',
                'HouseOwnerFlag', 'NumberCarsOwned']]
ytrain = TM.loc[TM.TrainTest == 1, ['BikeBuyer']]
Xtest = TM.loc[TM.TrainTest == 2,
              ['TotalChildren', 'NumberChildrenAtHome',
               'HouseOwnerFlag', 'NumberCarsOwned']]
ytest = TM.loc[TM.TrainTest == 2, ['BikeBuyer']]

# Check the data
Xtrain.shape
Xtrain.head(5)
ytrain.shape
ytrain.head(5)
Xtest.shape
Xtest.head(5)
ytest.shape
ytest.head(5)


# Fit the model 
model = GaussianNB()
model.fit(Xtrain, ytrain)

# Make predictions and check the accuracy
ymodel = model.predict(Xtest)
ymodel.shape
accuracy_score(ytest, ymodel)

# Output data
Xout = TM.loc[TM.TrainTest == 2,
             ['CustomerKey', 'BikeBuyer']]
Xout['Predicted'] = ymodel
Xout
