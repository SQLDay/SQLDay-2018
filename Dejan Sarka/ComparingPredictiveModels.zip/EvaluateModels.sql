USE AdventureWorksDW2014;
GO

-- Prediction results from multiple sources
/*
DROP TABLE IF EXISTS dbo.PredictionResults;
GO 
CREATE TABLE dbo.PredictionResults(
	[CustomerKey] [int] NULL,
	[Actual] [int] NULL,
	[Predicted] [bigint] NULL,
	[Source] [nvarchar](7) NULL
);
GO
*/

-- Execute the EvaluateModels package

SELECT *
FROM dbo.PredictionResults
ORDER BY CustomerKey, Source;


-- Pivoting to get A,B,C,D to calculate standard coeficients for the classification matrix
-- TN is the number of correct predictions that an instance is negative, 
-- FP is the number of incorrect predictions that an instance is positive, 
-- FN is the number of incorrect of predictions that an instance negative, and 
-- TP is the number of correct predictions that an instance is positive. 
SELECT Source, [00] As TN, [01] As FP, [10] As FN, [11] As TP
  FROM (SELECT Source, 
         CAST(Actual As char(1)) +
		 CAST(Predicted As char(1)) As ActualPredicted
        FROM dbo.PredictionResults) As bcm
        PIVOT
         (COUNT(ActualPredicted) FOR ActualPredicted
		  IN ( [00], [01], [10], [11] )) As pvt;

-- Derivations
-- TPR = sensitivity, recall, hit rate, or true positive rate (TPR)
-- TNR = specificity or true negative rate (TNR)
-- PPV = precision or positive predictive value (PPV)
-- NPV = negative predictive value (NPV)
-- FNR = miss rate or false negative rate (FNR)
-- FPR = fall-out or false positive rate (FPR)
-- FDR = false discovery rate (FDR)
-- FXR = false omission rate (FOR)
-- ACC = accuracy (ACC)
-- F1 score = the harmonic mean of precision and sensitivity
WITH ConfusionMatrixCTE AS
(
SELECT Source, [00] As TN, [01] As FP, [10] As FN, [11] As TP
  FROM (SELECT Source, 
         CAST(Actual As char(1)) +
		 CAST(Predicted As char(1)) As ActualPredicted
        FROM dbo.PredictionResults) As bcm
        PIVOT
         (COUNT(ActualPredicted) FOR ActualPredicted
		  IN ( [00], [01], [10], [11] )) As pvt)
SELECT Source, TN, FP, FN, TP,
 TPR = 1.0 * TP / (TP + FN),
 TNR = 1.0 * TN / (TN + FP),
 PPV = 1.0 * TP / (TP + FP),
 NPV = 1.0 * TN / (TN + FN),
 FNR = 1.0 * FN / (FN + TP),
 FPR = 1.0 * FP / (FP + TN),
 FDR = 1.0 * FP / (FP + TP),
 FXR = 1.0 * FN / (FN + TN),
 ACC = 1.0 * (TP + TN) / (TP + TN + FP + FN),
 F1  = 2.0 * TP / (2.0 * TP + FP + FN)
FROM ConfusionMatrixCTE;
GO
