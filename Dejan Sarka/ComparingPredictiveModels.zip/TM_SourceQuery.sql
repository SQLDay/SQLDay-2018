-- Source query from dbo.vTargetMail

USE AdventureWorksDW2014;
GO

SELECT CustomerKey, MaritalStatus, Gender,
 TotalChildren, NumberChildrenAtHome,
 EnglishEducation AS Education,
 EnglishOccupation AS Occupation,
 HouseOwnerFlag, NumberCarsOwned, CommuteDistance,
 Region, Age, YearlyIncome, BikeBuyer
FROM dbo.vTargetMail;
GO

-- Check the data after the split
SELECT *
FROM dbo.TMTrain;
SELECT *
FROM dbo.TMTest;
GO

