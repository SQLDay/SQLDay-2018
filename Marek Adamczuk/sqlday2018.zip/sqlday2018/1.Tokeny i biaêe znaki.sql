drop database if exists demo1;
GO
create database demo1;
GO
use demo1;
GO

-- Ile to token�w? Ile bia�ych znak�w?
select * from sys.objects;
GO




-- Bia�e znaki, �eby nie psu� zabawy :D











-- Terminacja token�w - spr�bujmy bez bia�ych znak�w
select*from.sys.objects;
GO




















--Bia�y znak CR+LF po ka�dym tokenie
select
*
from
.
sys
.
objects
;
GO







-- zagadka: ile mamy tu token�w?
select 1 where 1 <> 0;
GO












-- komentarz to te� bia�y znak
select 1 where 1 </*prawie jak xml*/> 0;
GO



-- separacja token�w - "trudniejszy przypadek"
-- litera� binarny
select 0xDeadBeef
GO











-- znajd� r�nic� 
select 0xdeadxbeef
GO


-- litera� walutowy
select $1;

select $1.;

select $;

select $1D;

select $d;

create table dbo.tmp1 ( g uniqueidentifier rowguidcol);
insert into dbo.tmp1 select newid();

select $rowguid from dbo.tmp1;
GO


-- deklaracja zmiennej 
declare @a int;
GO




-- da si� bez bia�ych znak�w?
declare@a[int];
GO







create or alter procedure declare@b @arg nvarchar(10) as select @arg arg;
GO
declare@b[int];
GO

sp_help declare@b



-- Czy to znaczy, �e ka�dy identyfikator regularny mo�e zawiera� w �rodku znak @?


create schema marek_adamczuk@hotmail;
GO
select 'Hej, jestem Marek' as content into marek_adamczuk@hotmail.com;
GO

select * from marek_adamczuk@hotmail.com;  -- email table :D
GO

-- uwaga, to nie jest m�j adres! Nie wysy�ajcie na niego pro�b o materia�y!!

-- jedynie s�uszny: 
marek.adamczuk@promise.pl

-- ile to token�w z punktu widzenia T-SQL?
GO
-- jak odwo�a� si� do takiego email table
GO
drop database if exists marek;
GO
create database marek;
GO
use marek;
GO
create schema adamczuk@promise;
GO

select 'Impossible is nothing' content into marek.adamczuk@promise.pl;

GO
select * from marek.adamczuk@promise.pl;
GO

-- czy kto� zna token w SQL Server , kt�ry zaczyna si� {



select {fn CURRENT_TIMESTAMP}
select {fn CURRENT_DATE()}
select {fn TRUNCATE(PI(),4)}

-- Udokumentowane!!! odbc scalar functions


create table dbo.temp_default (
a date default {fn CURRENT_DATE()},
b float default {fn TRUNCATE(PI(),4)}
);
GO
exec sp_helpconstraint temp_default;
GO



-- czyszczenie
use master;
GO
drop database demo1;
drop database marek;


