use master;
GO
drop database if exists demo3;
GO
create database demo3;
GO
use demo3;
GO
drop table if exists FKTable;
drop table if exists MasterTable;
GO
create table dbo.MasterTable(
  Id int identity primary key,
  KeyCol1 int,
  KeyCol2 int,
  unique (KeyCol1, KeyCol2),
  );
GO
create table dbo.FKTable (
  Id int identity primary key,
  aDate datetime default getdate(),
  aUser sysname default suser_sname(),
  fkCol1 int,
  fkCol2 int,
  foreign key (fkCol1, fkCol2) references dbo.MasterTable(KeyCol1, KeyCol2),
  check (fkCol1>fkCol2),
  unique (aDate,aUser)
  );
GO

drop table if exists #m; drop table if exists #fk;

-- zapami�tajmy nazwy wi�z�w
select o.name, o.type 
into #m
from sys.objects o 
where objectproperty (o.object_id,'IsConstraint')=1 
and o.parent_object_id = object_id('dbo.masterTable')


select o.name, o.type 
into #fk
from sys.objects o 
where objectproperty (o.object_id,'IsConstraint')=1 
and o.parent_object_id = object_id('dbo.fkTable')

select * From #fk;

-- recreate

drop table if exists FKTable;
drop table if exists MasterTable;

create table dbo.MasterTable(
  Id int identity primary key,
  KeyCol1 int,
  KeyCol2 int,
  unique (KeyCol1, KeyCol2),
  );
GO
create table dbo.FKTable (
  Id int identity primary key,
  aDate datetime default getdate(),
  aUser sysname default suser_sname(),
  fkCol1 int,
  fkCol2 int,
  foreign key (fkCol1, fkCol2) references dbo.MasterTable(KeyCol1, KeyCol2),
  check (fkCol1>fkCol2),
  unique (aDate,aUser)
  );
GO



select 'old' the_case, t.name, t.type
from #fk t
union all
select 'new', o.name, o.type
from sys.objects o
where objectproperty (o.object_id,'IsConstraint')=1 and o.parent_object_id = object_id('dbo.FKTable')
order by name;

select 'old' the_case, t.name, t.type
from #m t
union 
select 'new' the_case, o.name, o.type
from sys.objects o
where objectproperty (o.object_id,'IsConstraint')=1 and o.parent_object_id = object_id('dbo.MasterTable')
order by name, type;
GO

-- duplikacja funkcjonalna wi�z�w
GO
alter table dbo.FKTable add unique (aDate, aUser);
GO 5
alter table dbo.FKTable add foreign key (fkCOl1, fkCol2) references dbo.MasterTable(KeyCol1,KeyCOl2);
GO 5
alter table dbo.FKTable add check (fkCol1 > fkCol2)
GO 5

exec sp_helpconstraint FKTable;

-- co si� dzieje, gdy nazywamy wi�zy?
alter table dbo.FKTable add constraint UQ_FKTable_aDate_aUser unique (aDate, aUser);
GO 
alter table dbo.FKTable add constraint UQ_FKTable_aDate_asc_aUser_asc unique (aDate, aUser);
GO

alter table dbo.FKTable add constraint FK_FKTable_Master_Table
foreign key (fkCOl1, fkCol2) references dbo.MasterTable(KeyCol1,KeyCOl2);
GO 2
alter table dbo.FKTable add constraint FK_FKTable_Master_Table_KeyCol1_KeyCol2
foreign key (fkCOl1, fkCol2) references dbo.MasterTable(KeyCol1,KeyCOl2);
GO 2

-- Wniosek: Przed duplikacj� funkcjonaln� wi�zu chroni nas jedynie nazwa!
-- Jak zmienimy w locie konwencj� nazewnicz�, albo jej nie zastosujemy 
--         ********* NIE RATUJE NAS NIC ***********
select o.name, o.type
from sys.objects o
where objectproperty (o.object_id,'IsConstraint')=1 and o.parent_object_id = object_id('dbo.FKTable')
GO
-- co z indeksami? Tu trzeba poda� nazw�

create index I_FKTable_fkCol1_fkCOl2 on FKTable (fkCol1, fkCol2);
GO

select * from sys.indexes where object_id = object_id('dbo.fkTable') 
and is_primary_key = 0 and is_unique_constraint = 0
GO
-- co gdy dochodz� pola niekluczowe
create index I_FKTable_fkCol1_fkCOl2_INC_aDate_aUser on FKTable (fkCol1, fkCol2) 
include(aDate, aUSer);
GO
select * from sys.indexes 
where object_id = object_id('dbo.fkTable') and is_primary_key = 0 and is_unique_constraint = 0
GO
-- robi si� d�ugie!!!
create index I_F_FKTable_fkCol1_fkCOl2_INC_aDate_aUSer_WHERE_fkCol1_EQ_0
on FKTable (fkCol1, fkCol2) include(aDate, aUSer) where fkCol1 =0;
GO
-- a jeszcze clustered/nonclustered? unique? spatial? xml?


select * from sys.indexes where object_id = object_id('dbo.fkTable') and is_primary_key = 0 and is_unique_constraint = 0
GO
-- Wnioski: 
-- 1. na r�cznym wcze�niej czy p�niej polegniemy :(
-- 2. 128 znak�w mo�e nie starczy� ka�demu... 


-- goto RECREATE

-- Podej�cie automatyczne: Wymy�lmy najlepsz� mo�liw� nazw� dla wi�zu i przezwijmy go na ni�!
GO
create or alter function dbo.get_solid_name_F(@table_id int, @cnst_id int)
returns nvarchar(4000)
as
-- konwencja nazewnicza dla foreign key
begin
  declare @r_id int, @r NVARCHAR(4000) = N'';
  -- tabela, tabela do kt�rej si� odwo�ujemy 
  select @r = object_schema_name(@table_id)+'_'+object_name(@table_id) 
  select @r = @r + '&'+ object_schema_name(f.referenced_object_id)
  +'_'+object_name(f.referenced_object_id)
  +'U@'+f.update_referential_action_desc
  +'&D@'+f.delete_referential_action_desc+'&'
  from sys.foreign_keys f where f.object_id = @cnst_id;
  
  -- sklejamy kolumny
  SELECT TOP (255) @r = @r +  -- uwaga! Potencjalny antywzorzec!!! Running total na stringach
  col_name(fc.parent_object_id,fc.parent_column_id)+'_'
  FROM sys.foreign_key_columns fc
  JOIN sys.foreign_keys f ON fc.constraint_object_id = f.object_id
  JOIN sys.indexes i ON f.referenced_object_id = i.object_id AND f.key_index_id = i.index_id
  JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id 
  AND ic.column_id = fc.referenced_column_id
  WHERE 
  fc.parent_object_id = @table_id and fc.constraint_object_id = @cnst_id
  AND ic.key_ordinal > 0
  ORDER BY ic.key_ordinal;
  SET @r = SUBSTRING(@r,1,LEN(@r)-1)+'&';

  -- i jeszcze kolumny tabeli, do kt�rej si� odwo�ujemy
  SELECT TOP (255) @r = @r +
  COL_NAME(fc.referenced_object_id,fc.referenced_column_id)+'_'
  FROM sys.foreign_key_columns fc
  JOIN sys.foreign_keys f ON fc.constraint_object_id = f.object_id
  JOIN sys.indexes i ON f.referenced_object_id = i.object_id AND f.key_index_id = i.index_id
  JOIN sys.index_columns ic ON i.object_id = ic.object_id 
  AND i.index_id = ic.index_id and ic.column_id = fc.referenced_column_id
  WHERE 
  fc.parent_object_id = @table_id and fc.constraint_object_id = @cnst_id
  ORDER BY ic.key_ordinal
  SET @r = SUBSTRING(@r,1,LEN(@r)-1)
  return @r;
end;
GO
create or alter function dbo.get_solid_name_UQ(@table_id int, @cnst_id int)
returns nvarchar(4000)
as
-- konwencja nazewnicza dla unique
begin
  declare @r nvarchar(4000);
  select @r = object_schema_name(@table_id)+'_'+object_name(@table_id)
  
  SELECT top (255) @r =   @r + 
  concat(
  iif(c.index_id = 1 and c.key_ordinal = 1,'&C&','&N&'),
  col_name(c.object_id, c.column_id),
  iif(c.is_descending_key = 1,N'#desc',N'#asc'))
  FROM sys.key_constraints cns
  join sys.index_columns c on cns.parent_object_id = c.object_id and cns.unique_index_id = c.index_id
  where cns.parent_object_id = @table_id and cns.object_id = @cnst_id
  order by c.key_ordinal;
  return @r;
end;
GO
create or alter function dbo.get_solid_name_C(@table_id int, @cnst_id int)
returns nvarchar(4000)
as
-- konwencja nazewnicza dla check
begin
  declare @r nvarchar(4000);
  select @r = object_schema_name(@table_id)+'_'+object_name(@table_id)
  select @r = @r + replace(replace(c.definition,'[',''),']','') from sys.check_constraints c where c.object_id = @cnst_id;
  return @r;
end;
GO
create or alter function dbo.get_solid_name_D(@table_id int, @cnst_id int)
returns nvarchar(4000)
as
-- konwencja nazewnicza dla default
begin
  declare @r nvarchar(4000);
  select @r = object_schema_name(@table_id)+'_'+object_name(@table_id)+'_'
  select @r = @r+c.name from sys.default_constraints d 
  join sys.columns c on d.parent_object_id = c.object_id and d.parent_column_id = c.column_id
  where d.object_id = @cnst_id;
  return @r;
end;
GO
create or alter function dbo.get_solid_name_PK(@table_id int, @cnst_id int)
returns nvarchar(4000)
as
-- konwencja nazewnicza dla primary key
begin
  declare @r nvarchar(4000);
  select @r = object_schema_name(@table_id)+'_'+object_name(@table_id)
  return @r;
end;
GO
create or alter function dbo.get_solid_name(
  @table_id int, 
  @cnst_id int, 
  @type nvarchar(10), 
  @hash bit = 0)
returns nvarchar(4000)
as
-- zbiorcza funkcja konwencji nazewniczej wi�zu
begin
  declare @r nvarchar(4000);
  declare @fn_name sysname = 'dbo.get_solid_name_'+rtrim(convert(nvarchar(10),@type));
  exec @r = @fn_name @table_id, @cnst_id;
  if @hash = 0
    select @r = rtrim(@type)+'_'+@r;
  else
    select @r = rtrim(@type)+'_'+replace(convert(varchar(100),hashbytes('SHA2_256',@r),1),'0x','');
  return @r;
end;
GO
-- sprawdzamy nowe nazwy
select type, name,
dbo.get_solid_name(o.parent_object_id, o.object_id, o.type,0) SolidName
from sys.objects o
where OBJECTPROPERTYEX(object_id,'IsConstraint')=1
and o.parent_object_id = object_id('dbo.FKTable')
GO
select type, name,
dbo.get_solid_name(o.parent_object_id, o.object_id, o.type,1) SafeBadSolidName
from sys.objects o
where OBJECTPROPERTYEX(object_id,'IsConstraint')=1
and o.parent_object_id = object_id('dbo.FKTable')
GO
create or alter procedure dbo.rename_constraints @table_id int, @hash bit = 0
as
-- zmiana nazw wi�z�w na zgodne z konwencj� nazewnicz�
begin
  declare @sql nvarchar(max) = ''; declare @r int = 0;
  select top (100000) @sql = @sql+
  concat(
  'exec sp_rename '+quotename(o.name,''''),',',
  quotename(dbo.get_solid_name(o.parent_object_id, o.object_id, o.type,@hash),''''),
  ';',char(13),char(10)
  )
  from sys.objects o
  where OBJECTPROPERTYEX(object_id,'IsConstraint')=1
  and o.parent_object_id = @table_id
  and o.name <> dbo.get_solid_name(o.parent_object_id, o.object_id, o.type,@hash) 
  order by o.type, o.create_date
--  select @sql;
  begin try
    exec (@sql);
  end try
  begin catch
    print error_message();
    set @r = 666
  end catch;
  return @r;
end;
GO
declare @id int = object_id('dbo.FKTable')
exec dbo.rename_constraints @id;
GO

sp_helpconstraint FKTable;


drop trigger if exists [DDLTR_RENAME_CONSTRAINTS] on database;
GO

drop table if exists FKTable;
drop table if exists MasterTable;

create table dbo.MasterTable(
  Id int identity primary key,
  KeyCol1 int,
  KeyCol2 int,
  unique (KeyCol1, KeyCol2),
  );
GO
create table dbo.FKTable (
  Id int identity primary key,
  aDate datetime default getdate(),
  aUser sysname default suser_sname(),
  fkCol1 int,
  fkCol2 int,
  foreign key (fkCol1, fkCol2) references dbo.MasterTable(KeyCol1, KeyCol2),
  check (fkCol1>fkCol2),
  unique (aDate,aUser)
  );
GO

drop trigger if exists [DDLTR_RENAME_CONSTRAINTS] on database;
GO
create or alter trigger [DDLTR_RENAME_CONSTRAINTS]
on database
for CREATE_TABLE, ALTER_TABLE
as
begin
	declare @e xml = eventdata();
	declare @Name sysname, 
  @Schname sysname, @TargetObjectName sysname,
  @ObjectType sysname, @EventType sysname, @TableId int, @R int;

	select
	@ObjectType = @e.value('/EVENT_INSTANCE[1]/ObjectType[1]','nvarchar(128)'),
	@EventType = @e.value('/EVENT_INSTANCE[1]/EventType[1]','nvarchar(128)'),
	@Name = @e.value('/EVENT_INSTANCE[1]/ObjectName[1]','nvarchar(128)'),
	@Schname = @e.value('/EVENT_INSTANCE[1]/SchemaName[1]','nvarchar(128)')
  
  select @TableId = object_id(quotename(@Schname)+'.'+quotename(@name));
  if @TableId is not null begin
    exec @R = dbo.rename_constraints @TableId;
    if @R <> 0 rollback;
  end;
end;
GO
alter table dbo.fktable add unique (aUser);
GO
alter table dbo.fktable add unique (aUser)
GO
alter table fktable add unique (aUser desc)
GO

sp_helpconstraint fkTable;
GO
-- wersja z hash
declare @id int = object_id('dbo.FKTable')
exec dbo.rename_constraints @id,1;
GO
sp_helpconstraint fkTable;
GO


-- DO DOMU! To samo dla indeks�w!
-- UWAGA NA!
-- 1. Pola niekluczowe (INCLUDE)
-- 2. Filtr (WHERE)
-- 3. Klastrowany/nieklastrowany, unikalny
-- 4. Inne typy indeks�w: COLUMNSTORE, SPATIAL, XML itd.


