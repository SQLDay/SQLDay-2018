-- najkr�tsza nazwa zmiennej
declare @ int;
set @ = 1;
select @;
GO

-- joiny: wszystkie on na koniec
select * 
from sys.objects o
join sys.columns c 
join sys.types t
on t.system_type_id = c.system_type_id
on o.object_id = c.object_id
GO
-- kolejno�� ON-�w ma znaczenie, dzia�amy na zasadzie stosu
select * 
from sys.objects o
join sys.columns c 
join sys.types t
on o.object_id = c.object_id
on t.system_type_id = c.system_type_id
GO
-- create table: przecinek po ostatniej kolumnie
create table #t1 (
  a int, 
  b int,
  )
GO
-- brak przecinka po ostatniej kolumnie, a przed wi�zami
create table #t2 (
  a int, 
  b int  -- tu brak przecinka
  constraint PK1 primary key (a),
  constraint UQ1 unique (b), -- za to tu jest
  )
GO


-- zmienne tabelaryczne nie s� ju� tak liberalne

declare @t1 table (
  a int, 
  b int,
  )
GO
declare @t2 table (
  a int, 
  b int  -- tu brak przecinka
  constraint PK1 primary key (a),
  constraint UQ1 unique (b),
  )
GO


-- aliasowe typy danych;
drop table if exists dbo.mega_types;
GO
create table dbo.mega_types (
  col1 dec,
  col2 character(10),
  col3 national character(20),
  col4 national character varying (30)
  );
GO
sp_help mega_types;
GO

create table dbo.timestamp_tab (
    id int identity primary key,
    a nvarchar(10),
    timestamp
)
GO
sp_help timestamp_tab;
GO
-- dowolnie wiele prefix�w w insert list
insert into dbo.mega_types (col1, col2, col3, col4)
select 1,'a','b','c'


insert into dbo.mega_types (a1.a2.a3.t.col1, t.col2, tabbbb.col3, aqqqqq.tu.jestem.col4)
select 1,'a','b','c'
GO

-- to ju� nie dzia�a :(

-- set bez niczego
set;
GO

-- stary raiserror
raiserror 50001,'B��d'




-- obiekty jak systemowe
GO
create table dbo.sysobjects (
  a int,
  b int,
  )
GO
insert into dbo.sysobjects (a, b) values (1,1);
GO
select * from dbo.sysobjects; -- ze schematem
GO
if object_id('dbo.sysobjects') is not null drop table dbo.sysobjects;
GO
select object_id('dbo.sysobjects');
GO
drop table if exists dbo.sysobjects;
GO
create procedure dbo.sp_help as select 'help';
GO
exec dbo.sp_help
GO
sp_helptext 'dbo.sp_help';
GO
drop procedure if exists sp_help;
GO

-- sk�adnia tylko dla Microsoftu!

sp_helptext 'sys.databases';
GO
select sysconv(bit,0x001)
select * from OpenRowset(TABLE DBPROP,1);
GO
sp_helptext 'sys.sp_rename';

EXEC %%ScalarType(MultiName = @SchemaAndTypeName).LockMatchID(ID = @xusertype, Exclusive = 1)

-- DML na funkcji skalarnej
GO
create or alter function dbo.get_mega_types (@col1 int)
returns table
as return (select * from dbo.mega_types where col1 = @col1);
GO
insert into dbo.get_mega_types(2) (col1,col2,col3,col4) select 2,'a','b','c';
GO
select * from dbo.mega_types;
GO
delete from dbo.get_mega_types(1);
GO
select * from dbo.mega_types;
GO
update dbo.get_mega_types(2) set col4 = 'xxx';
GO
-- instead of trigger?
create trigger TR_Get_mega_types -- @col1 int???
on dbo.get_mega_types
instead of insert
as
select 1;
GO
-- with check option (jak w view)?

create or alter function dbo.get_mega_types (@col1 int)
returns table
as return (select * from dbo.mega_types where col1 = @col1)
with check option;
GO

create or alter function dbo.get_mega_types (@col1 int)
returns table
as return (select * from dbo.mega_types where col1 = @col1 with check option);
GO



-- instrukcja pusta. Co wstawi� m�dzy begin a end, �eby nic nie oznacza�o?
if 1 = 1 
begin

end;
GO

if 1 = 1 
begin
  LABEL:
end;
GO
