dbcc freeproccache;
GO
use AdventureWorks2014
GO
select count(*) from Production.Product;
GO
select * from Production.Product where Name like 'Mount%'
GO
select * from Production.Product where Name like 'Decal%'
GO
select * from sys.syscacheobjects where sql like '%Production.Product%' option (recompile);
GO
exec sp_executesql N'select * from Production.Product where Name like @Name',
N'@Name nvarchar(200)',@Name = 'Mount%' 
GO
exec sp_executesql N'select * from Production.Product where Name like @Name',
N'@Name nvarchar(200)',@Name = 'Decal%' 
GO

-- Bawimy si� w optymalizator SQL-a. Wiemy, �e sprzedajemy rowery g�rskie. 
--Implementujemy prawdziwy query hint (nie query order!)
GO
dbcc freeproccache;
GO
exec sp_executesql N'select * /*DO THE SCAN!*/ from Production.Product where Name like @Name',
N'@Name nvarchar(200)',@Name = 'Mount%' 
GO
exec sp_executesql N'select * /*DO THE SEEK + KL!*/ from Production.Product where Name like @Name',
N'@Name nvarchar(200)',@Name = 'Decal%' 
GO
select * from sys.syscacheobjects where sql like '%Production.Product%' and objtype = 'Prepared' option (recompile);
GO
-- ta sama warto�� parametru! Ju� bez znaczenia, bo mamy plany. To od nas zale�y, kt�ry wybierzemy
exec sp_executesql N'select * /*DO THE SCAN!*/ from Production.Product where Name like @Name',
N'@Name nvarchar(200)',@Name = 'HL%' 
GO
exec sp_executesql N'select * /*DO THE SEEK + KL!*/ from Production.Product where Name like @Name',
N'@Name nvarchar(200)',@Name = 'HL%' 
GO

select * from sys.syscacheobjects where sql like '%Production.Product%' and objtype = 'Prepared' option (recompile);

-- czy da si� z tego skorzysta� w rzeczywistych aplikacjach?
-- PEWNIE, �E TAK!!!
-- Np. wy�wietlamy zdarzenia z filtrem na zakres dat. Je�li jest relatywnie ma�y (np 1 dzie�) sugerujemy seek, w przeciwnym wypadku scan

-- Co pisa� w naszym query hint?
-- 1. Nie za du�o r�nych warto�ci (dos�ownie kilka)
-- 2. Zawsze wymy�lone przez nas


-- NIGDY NIE POZWALAMY NA STEROWANIE PRZEZ U�YTKOWNIKA HINTAMI

-- Kto tak pisze zapytania, generowane przez aplikacj�?
GO
/*
System:                Moja powa�na biznesowa aplikacja
Wersja:                3.14.1592
Zapytanie:             info o bazie danych, wersja zapytania 5
U�ytkownik aplikacji:  mojadomena\heniek.kowalski
Czas uruchomienia:     2018-05-05 23:30:01
Parametry zapytania:   @name = 'AdventureWorks2014' 
*/
declare @name sysname = 'AdventureWorks2014';
exec sp_helpdb @name;
GO











declare @UserInput nvarchar(200);
set @UserInput = N'HL%' -- tu radosna tw�rczo�� usera
declare @Query nvarchar(max);
select @Query = N'select * /*'+@UserInput+'*/ from Production.Product where Name like @Name'
exec sp_executesql @Query, N'@Name nvarchar(200)', @Name = @UserInput
GO

select * /*1*/from sys.types; create table tu_bylem_heniek(i int)select */* ?%*/ from Production.Product where Name like @Name









drop table if exists dbo.tu_bylem_heniek;
GO
declare @UserInput nvarchar(200);
set @UserInput = N'1*/from sys.types; create table tu_bylem_heniek(i int)select */* ?%' -- tu radosna TFUrczo�� usera
declare @Query nvarchar(max);
select @Query = N'select * /*'+@UserInput+'*/ from Production.Product where Name like @Name'
select @Query query;
exec sp_executesql @Query, N'@Name nvarchar(200)', @Name = @UserInput
GO
select * from dbo.tu_bylem_heniek;


-- czy ratuje nas komentarz jednolinijkowy?
declare @UserInput nvarchar(200);
set @UserInput = N'HL%' -- tu radosna tw�rczo�� usera
declare @Query nvarchar(max);
select @Query = N'select * 
-- '+@UserInput+'
from Production.Product where Name like @Name'
select @Query;
exec sp_executesql @Query, N'@Name nvarchar(200)', @Name = @UserInput
GO





drop table if exists dbo.tu_bylam_zuza;
GO
declare @UserInput nvarchar(200); 
declare @cr nvarchar(200) = char(13)+char(10);
select @UserInput = N''+@cr+'from sys.types; create table dbo.tu_bylam_zuza(i int); select *'+@cr+'--' -- tu radosna TFUrczo�� usera
declare @Query nvarchar(max);
select @Query = N'select * 
-- '+@UserInput+'
from Production.Product where Name like @Name'
select @Query;
exec sp_executesql @Query, N'@Name nvarchar(200)', @Name = @UserInput
GO
select * from dbo.tu_bylam_zuza;


-- mo�e zadzia�a sam CR?
drop table if exists dbo.tu_bylam_zuza;
GO
declare @UserInput nvarchar(200); 
declare @cr nvarchar(200) = char(13);
select @UserInput = N''+@cr+'from sys.types; create table dbo.tu_bylam_zuza(i int); select *'+@cr+'--' -- tu radosna TFUrczo�� usera
declare @Query nvarchar(max);
select @Query = N'select * 
-- '+@UserInput+'
from Production.Product where Name like @Name'
exec sp_executesql @Query, N'@Name nvarchar(200)', @Name = @UserInput
GO
select * from dbo.tu_bylam_zuza;

-- mo�e sam LF?
drop table if exists dbo.tu_bylam_zuza;
GO
declare @UserInput nvarchar(200); 
declare @cr nvarchar(200) = char(10);
select @UserInput = N''+@cr+'from sys.types; create table dbo.tu_bylam_zuza(i int); select *'+@cr+'--' -- tu radosna TFUrczo�� usera
declare @Query nvarchar(max);
select @Query = N'select * 
-- '+@UserInput+'
from Production.Product where Name like @Name'
exec sp_executesql @Query, N'@Name nvarchar(200)', @Name = @UserInput
GO
select * from dbo.tu_bylam_zuza;

-- Wnioski
-- 1. Jak pozwalamy na user input w komentarzu, prosimy si� o SQL Injection
-- 2. Pami�tamy o znaku terminacji komentarza. Dla blokowego: */, dla jednolinijkowego: dowolny koniec linii
GO


use demo3;

drop trigger if exists [DDLTR_RENAME_CONSTRAINTS] on database;
GO
create or alter trigger [DDLTR_RENAME_CONSTRAINTS]
on database
for CREATE_TABLE, ALTER_TABLE
as
begin
	declare @e xml = eventdata();
  select @e;
	declare @Name sysname, 
  @Schname sysname, @TargetObjectName sysname,
  @ObjectType sysname, @EventType sysname, @TableId int, @R int;

  declare @Command nvarchar(max);

	select
	@ObjectType = @e.value('/EVENT_INSTANCE[1]/ObjectType[1]','nvarchar(128)'),
	@EventType = @e.value('/EVENT_INSTANCE[1]/EventType[1]','nvarchar(128)'),
	@Name = @e.value('/EVENT_INSTANCE[1]/ObjectName[1]','nvarchar(128)'),
	@Schname = @e.value('/EVENT_INSTANCE[1]/SchemaName[1]','nvarchar(128)'),
  @Command = @e.value('/EVENT_INSTANCE[1]/TSQLCommand[1]/CommandText[1]','nvarchar(max)');
  
  select @TableId = object_id(quotename(@Schname)+'.'+quotename(@name));
  if @TableId is not null 
  and @Command not like '%SET NO_RENAME ON%'
  begin
    exec @R = dbo.rename_constraints @TableId;
    if @R <> 0 rollback;
  end;
end;
GO
use 
sp_helpconstraint FKTable;
GO
alter table FKTable add constraint CKDummy111 check( 1 = 1);


alter table FKTable /*SET NO_RENAME ON*/ add constraint CKDummy check( 1 = 1);
GO
-- byle nie na ko�cu! Obcinaj� ostatni bia�y znak!
GO
alter table FKTable add constraint CKDummy1 check( 1 = 1);--SET NO_RENAME ON
GO

-- czy to bezpieczne?
-- czy kiedy� znormalizuj� nam ca�y TSQLCommand (wywal� bia�e znaki)?
-- alternatywa: SESSION_CONTEXT(), by�o o tym na poprzednim SQL Day;




