drop database if exists demo2;
create database demo2;
GO
use demo2;
GO
create or alter function dbo.object_lines(@Objectname sysname)
returns @t table (line nvarchar(max), id int identity primary key)
as
begin
  insert into @t (line)
  exec sp_helptext @Objectname;
  return;
end;
GO

create or alter function dbo.object_lines(@Objectname sysname)
returns @t table (line nvarchar(max), id int identity primary key)
as
begin
  exec sp_helptext @Objectname;
  return;
end;
GO
select * from dbo.object_lines('dbo.object_lines');
GO
/*
Msg 557, Level 16, State 2, Line 9
Only functions and some extended stored procedures can be executed from within a function.
*/
GO
create or alter function dbo.arith_add (@arg1 float = 0,  @arg2 float = 0)
returns float
as
begin
  return (@arg1 + @arg2);
end;
GO
-- A mo�e jednak? .... Strza� z biodra!
exec dbo.arith_add;
GO

-- pytanie czy to w og�le dzia�a?

-- przekazujemy parametry, normalnie jak do funkcji
exec dbo.arith_add (12, 23)






-- a mo�e "normalnie", jak przy procedurze
exec dbo.arith_add 12, 23


-- Dalej nie wiemy czy dzia�a. Tylko co z warto�ci� zwracan�?? 
-- Jak to odebra�??? Mo�e znowu jak przy procedurze????

declare @result float;
exec @result = dbo.arith_add 213, 234.5;
select @result;

-- a mo�e nie trzeba ju� odwo�ywa� si� z dbo?? "normalnie" jak przy procedurze...??
GO
declare @result float;
exec @result = arith_add 213, 234.5;
select @result;

-- no to mo�e "normalnie" dzia�aj� warto�ci domy�lne parametr�w??? 
-- bez pisania default??? jak przy procedurze????
GO
declare @result float;
exec @result = arith_add 213;
select @result;

-- zaimplementujmy odejmowanie
GO
create or alter function dbo.arith_substract (@arg1 float = 0,  @arg2 float = 0)
returns float
as
begin
  return (@arg1 - @arg2);
end;
GO

-- to mo�e da si� przekaza� parametry z jawnym wskazaniem parametr�w formalnych
GO
declare @result float;
exec @result = arith_substract @arg2 = 5;
select @result;
GO
-- w odwrotnej kolejno�ci?
declare @result float;
exec @result = arith_substract @arg2 = 5, @arg1 = 100
select @result;
GO
-- To do kompletu jeszcze mno�enie i dzielenie

create or alter function dbo.arith_multiply(@arg1 float = 0,  @arg2 float = 0)
returns float
as
begin
  return (@arg1 * @arg2);
end;
GO
create or alter function dbo.arith_divide(@arg1 float = 0,  @arg2 float = 0)
returns float
as
begin
  return (@arg1 / NULLIF(@arg2,0));
end;
GO

-- no to jeszcze spr�bujmy dynamicznie, i exec wewn�trz funkcji skalarnej
GO
create or alter function dbo.arith(@operation nvarchar(20),@arg1 float = 0, @arg2 float = 0)
returns float
as
begin
  declare @fnname sysname, @result float;
  select @fnname = 'dbo.arith_'+@operation;
  exec @result = @fnname @arg1, @arg2;
  return @result;
end;
GO
-- a wywo�amy teraz tradycyjnie
select 
dbo.arith('add',6,2) as [add], 
dbo.arith('substract',6,2) as [substract], 
dbo.arith('multiply',6,2) as [multiply], 
dbo.arith('divide',6,2) as [divide]
GO
-- b��dy
select dbo.arith('power',6,2)
GO
drop function dbo.arith;
drop function dbo.arith_add;
drop function dbo.arith_substract;
drop function dbo.arith_divide;
drop function dbo.arith_multiply;
GO
use master;
GO
drop database demo2;
GO
-- wnioski
-- 1. exec jest dozwolony na funkcjach skalarnych!
-- 2. Bardzo wiele ogranicze� przypisywanych funkcjom, 
--    dotyczy nie typu obiektu, a sposobu wywo�ania!!!
-- 3. Funkcje skalarne mog� wi�cej ni� nam si� do tej pory wydawa�o




