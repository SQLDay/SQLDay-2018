﻿#setup your account
Login-AzureRmAccount

#verify your subscriptions
Get-AzureRmSubscription

#set your default Subscription
Get-AzureRmSubscription `
–SubscriptionName “Pay-As-You-Go” | Select-AzureRmSubscription

#create the Azure SQL server
$adminCredential = Get-Credential

New-AzureRmSqlServer -ResourceGroupName "sqldayrg" `
-Location "West Europe" `
-ServerName "sqldayserver1" `
-SqlAdministratorCredentials $adminCredential `
-ServerVersion "12.0"

#make my AAD user an admin
Set-AzureRmSqlServerActiveDirectoryAdministrator -ResourceGroupName "sqldayrg" -ServerName "sqldayserver1" -DisplayName "Hubert Kobierzewski"


#create a new Basic database
New-AzureRmSqlDatabase `
-DatabaseName "db1" `
-ServerName "sqldayserver1" `
-ResourceGroupName "sqldayrg" `
-Edition "Basic"
