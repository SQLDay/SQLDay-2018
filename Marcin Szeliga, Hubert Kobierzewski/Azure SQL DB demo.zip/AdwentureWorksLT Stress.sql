select count(*) from SalesLT.[Customer];
select count(*) from SalesLT.[CustomerAddress];
select count(*) from dbo.[ErrorLog];
select count(*) from SalesLT.[ProductCategory];
select count(*) from SalesLT.[ProductModel];
select count(*) from SalesLT.[Product];
select count(*) from SalesLT.[ProductDescription];
select count(*) from SalesLT.[ProductModelProductDescription];
select count(*) from SalesLT.[SalesOrderHeader];
select count(*) from SalesLT.[SalesOrderDetail];

select *
into #tempCustomer
from SalesLT.Customer

select AddressLine1, AddressLine2, City, StateProvince
from SalesLT.Address
where CountryRegion='Canada';

select AddressLine1, AddressLine2, City, StateProvince
from SalesLT.Address
where CountryRegion='United States';

select Title + ' ' + FirstName + ' ' + MiddleName + ' ' + LastName, CompanyName
from SalesLT.Customer
where CompanyName like 'S%' and MiddleName is not null

select sum(Weight) totalWeight, ProductCategoryID, Color
from SalesLT.Product
group by ProductCategoryID, Color
order by totalWeight desc

select Description
from SalesLT.ProductDescription
where Description like 'R%'
order by ModifiedDate desc

select Description
from SalesLT.ProductDescription
where Description like 'T%'
order by ModifiedDate desc

select sum(OrderQty) totalQty, sum(UnitPrice) totalPrice, ProductID
from SalesLT.SalesOrderDetail
where OrderQty > 10
group by ProductID
order by totalQty, totalPrice