﻿#setup your account
Login-AzureRmAccount

#verify your subscriptions
Get-AzureRmSubscription

#set your default Subscription
Get-AzureRmSubscription `
–SubscriptionName “Pay-As-You-Go” | Select-AzureRmSubscription

#create the elastic pool
New-AzureRmSqlElasticPool `
-ResourceGroupName "sqldayrg" `
-ServerName "sqldayserver1" `
-ElasticPoolName "sqldayPool" `
-Edition "Standard" `
-Dtu 100 `
-DatabaseDtuMin 10 `
-DatabaseDtuMax 100

#move databases into the pool
Set-AzureRmSqlDatabase `
-ResourceGroupName "sqldayrg" `
-ServerName "sqldayserver1" `
-DatabaseName "db1" `
-ElasticPoolName "sqldayPool"

Set-AzureRmSqlDatabase `
-ResourceGroupName "sqldayrg" `
-ServerName "sqldayserver1" `
-DatabaseName "db2" `
-ElasticPoolName "sqldayPool"
