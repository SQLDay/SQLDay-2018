options(scipen=999)  
library(ggplot2)

# dane
data("midwest", package = "ggplot2")

# wybór data.frame, definicja osi
ggplot(midwest, aes(x=area, y=poptotal)) 

# wykres punktowy
ggplot(midwest, aes(x=area, y=poptotal)) + geom_point()

wykres <- ggplot(iris, aes(x=Petal.Width, y=Petal.Length))
wykres
wykres + geom_point()
wykres + geom_boxplot()

# dodatkowy element - model liniowy z przedziałem ufności
g <- ggplot(midwest, aes(x=area, y=poptotal)) + geom_point() + geom_smooth(method="lm")
plot(g)

wykres + geom_point() + geom_smooth(method = "lm")

# zakres wartości - punkty spoza zakresu są usuwane
g + xlim(c(0, 0.1)) + ylim(c(0, 500000))

# punkty spoza zakresu nie są widoczne
g1 <- g + coord_cartesian(xlim=c(0,0.1), ylim=c(0, 500000))
g1

# Etykiety i tytuły
g1 + labs(title="Area Vs Population", subtitle="From midwest dataset", y="Population", x="Area", caption="Midwest Demographics")
# lub
g1 + ggtitle("Area Vs Population", subtitle="From midwest dataset") + xlab("Area") + ylab("Population")

# modyfikacje elementów wykresu
ggplot(midwest, aes(x=area, y=poptotal)) + 
  geom_point(col="steelblue", size=3) + 
  geom_smooth(method="lm", col="firebrick") + 
  coord_cartesian(xlim=c(0, 0.1), ylim=c(0, 1000000)) + 
  labs(title="Area Vs Population", 
       subtitle="From midwest dataset", 
       y="Population", 
       x="Area", 
       caption="Midwest Demographics")

wykres <- ggplot(midwest, aes(x=area, y=poptotal)) + 
  geom_point(aes(col=state), size=3) + 
  geom_smooth(method="lm", col="firebrick") + 
  coord_cartesian(xlim=c(0, 0.1), ylim=c(0, 1000000)) + 
  labs(title="Area Vs Population", 
       subtitle="From midwest dataset", 
       y="Population", 
       x="Area", 
       caption="Midwest Demographics")
wykres + scale_colour_brewer(palette = "Set1")

# dostępne palety barw
library(RColorBrewer)
brewer.pal.info

# zmiana definicji osi
wykres + scale_x_continuous(breaks=seq(0, 0.1, 0.01))
wykres + scale_x_continuous(breaks=seq(0, 0.1, 0.01), labels = letters[1:11])

# odwrócenie osi
wykres + scale_x_reverse()

# więcej modyfikacji theme

# wykres
gg <- ggplot(midwest, aes(x=area, y=poptotal)) + 
  geom_point(aes(col=state, size=popdensity)) + 
  geom_smooth(method="loess", se=F) + xlim(c(0, 0.1)) + ylim(c(0, 500000)) + 
  labs(title="Area Vs Population", subtitle = "Midwest dataset", 
       y="Population", x="Area", caption="Source: midwest")

# modyfikacje
windowsFonts(Times=windowsFont("Times New Roman")) 
gg + theme(plot.title=element_text(size=20, 
                                   face="bold", 
                                   family="Times",
                                   color="tomato",
                                   hjust=0.5,
                                   lineheight=1.2),  # title
           plot.subtitle=element_text(size=15, 
                                      family="Times",
                                      face="bold",
                                      hjust=0.5),  # subtitle
           plot.caption=element_text(size=15),  # caption
           axis.title.x=element_text(vjust=10,  
                                     size=15),  # X axis title
           axis.title.y=element_text(size=15),  # Y axis title
           axis.text.x=element_text(size=10, 
                                    angle = 30,
                                    vjust=.5),  # X axis text
           axis.text.y=element_text(size=10))  # Y axis text

# ręcznie dobrane kolory i opisy
gg + scale_color_manual(name="State", 
                        labels = c("Illinois", 
                                   "Indiana", 
                                   "Michigan", 
                                   "Ohio", 
                                   "Wisconsin"), 
                        values = c("IL"="blue", 
                                   "IN"="red", 
                                   "MI"="green", 
                                   "OH"="brown", 
                                   "WI"="orange"))

# modyfikacje legendy
gg + theme(legend.title = element_text(size=12, color = "firebrick"), 
           legend.text = element_text(size=10),
           legend.key=element_rect(fill='springgreen')) + 
  guides(colour = guide_legend(override.aes = list(size=2, stroke=1.5))) 

# inna pozycja legendy
gg + theme(legend.title = element_text(size=12, color = "salmon", face="bold"),
           legend.justification=c(0,1), 
           legend.position=c(0.05, 0.95),
           legend.background = element_blank(),
           legend.key = element_blank())

midwest_sub <- midwest[midwest$poptotal > 300000, ]
midwest_sub$large_county <- ifelse(midwest_sub$poptotal > 300000, midwest_sub$county, "")

# etykiety na wykresie
gg + geom_text(aes(label=large_county), size=2, data=midwest_sub)

library(ggrepel)
gg + geom_text_repel(aes(label=large_county), 
                     size=2, 
                     data=midwest_sub) + 
  labs(subtitle="With ggrepel::geom_text_repel") + 
  theme(legend.position = "None")   

gg + geom_label_repel(aes(label=large_county), 
                      size=2, data=midwest_sub) + 
  labs(subtitle="With ggrepel::geom_label_repel") + 
  theme(legend.position = "None")

# dowolny tekst na wykresie
library(grid)
my_text <- "This text is at x=0.7 and y=0.8!"
my_grob = grid.text(my_text, x=0.7,  y=0.8, gp=gpar(col="firebrick", fontsize=14, fontface="bold"))
gg + annotation_custom(my_grob)


# inne dodatki
p=ggplot(mtcars, aes(x = wt, y = mpg)) + geom_point()
# Add text on a specific positions:
p + annotate("text", x = c(2,4.5), y = c(20,25), label = c("label 1", "label 2") , color="orange", size=5 , angle=45, fontface="bold")
# Add rectangles
p + annotate("rect", xmin=c(2,4), xmax=c(3,5), ymin=c(20,10) , ymax=c(30,20), alpha=0.2, color="blue", fill="blue")
# Add segments
p + annotate("segment", x = 1, xend = 3, y = 25, yend = 15, colour = "purple", size=3, alpha=0.6)
# Add arrow
p + annotate("segment", x = 2, xend = 4, y = 15, yend = 25, colour = "red", size=3, alpha=0.6, arrow=arrow())

# fasetowanie
# wiele wykresów na jednym 
g <- ggplot(mpg, aes(x=displ, y=hwy)) + 
  geom_point() + 
  geom_smooth(method="lm", se=FALSE) + 
  theme_bw()  

g + facet_wrap( ~ class, nrow=2) + 
  labs(title="hwy vs displ", 
       caption = "Source: mpg", 
       subtitle="Ggplot2 - Faceting - Multiple plots in one figure")

g + facet_wrap( ~ class, scales = "free") + 
  labs(title="hwy vs displ", 
       caption = "Source: mpg", 
       subtitle="Ggplot2 - Faceting - Multiple plots in one figure with free scales")  

g1 <- g + facet_grid(manufacturer ~ class)  
g2 <- g + facet_grid(cyl ~ class)

library(gridExtra)
gridExtra::grid.arrange(g1, g2, ncol=2)

#

library(ggplot2)
gg <- ggplot(diamonds, aes(x=carat, y=price)) 
gg1 <- gg + geom_point()
p1 <- gg1 + facet_grid(color ~ cut)
p2 <- gg1 + facet_wrap(color ~ cut, scales="free") 
p1
p2

###################
## Problemy z wizualizacją danych

library(ggplot2)
data(mpg, package="ggplot2") 
theme_set(theme_bw())

g <- ggplot(mpg, aes(cty, hwy))

g + geom_point() + 
  geom_smooth(method="lm", se=F) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Scatterplot with overlapping points", 
       caption="Source: midwest")

# rozmiar danych - czy na pewno wszystkie są na wykresie? 
dim(mpg)
g + geom_point()

# jitter
g + geom_jitter(width = .5, size=1) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Jittered Points")

# rozmiar punktu
g + geom_count(col="tomato3", show.legend=F) +
  labs(subtitle="mpg: city vs highway mileage", 
       y="hwy", 
       x="cty", 
       title="Counts Plot")


##################

library(ggExtra)
data(mpg, package="ggplot2")

# Scatterplot
theme_set(theme_bw())  # pre-set the bw theme.
mpg_select <- mpg[mpg$hwy >= 35 & mpg$cty > 27, ]
g <- ggplot(mpg, aes(cty, hwy)) + 
  geom_count() + 
  geom_smooth(method="lm", se=F)

ggMarginal(g, type = "histogram", fill="transparent")
ggMarginal(g, type = "boxplot", fill="transparent")
ggMarginal(g, type = "density", fill="transparent")

###################

# devtools::install_github("kassambara/ggcorrplot")
library(ggplot2)
library(ggcorrplot)

data(mtcars)
corr <- round(cor(mtcars), 1)

ggcorrplot(corr, hc.order = TRUE, 
           type = "lower", 
           lab = TRUE, 
           lab_size = 3, 
           method="circle", 
           colors = c("tomato2", "white", "springgreen3"), 
           title="Correlogram of mtcars", 
           ggtheme=theme_bw)

###################

library(ggplot2)
theme_set(theme_bw())

data("mtcars")  # load data
mtcars$`car name` <- rownames(mtcars)  # create new column for car names
mtcars$mpg_z <- round((mtcars$mpg - mean(mtcars$mpg))/sd(mtcars$mpg), 2)  # compute normalized mpg
mtcars$mpg_type <- ifelse(mtcars$mpg_z < 0, "below", "above")  # above / below avg flag
mtcars <- mtcars[order(mtcars$mpg_z), ]  # sort
mtcars$`car name` <- factor(mtcars$`car name`, levels = mtcars$`car name`)  # convert to factor to retain sorted order in plot.

ggplot(mtcars, aes(x=`car name`, y=mpg_z, label=mpg_z)) + 
  geom_point(stat='identity', fill="black", size=6)  +
  geom_segment(aes(y = 0, 
                   x = `car name`, 
                   yend = mpg_z, 
                   xend = `car name`), 
               color = "black") +
  geom_text(color="white", size=2) +
  labs(title="Diverging Lollipop Chart", 
       subtitle="Normalized mileage from 'mtcars': Lollipop") + 
  ylim(-2.5, 2.5) +
  coord_flip()

ggplot(mtcars, aes(x=`car name`, y=mpg_z, label=mpg_z)) + 
  geom_point(stat='identity', aes(col=mpg_type), size=6)  +
  scale_color_manual(name="Mileage", 
                     labels = c("Above Average", "Below Average"), 
                     values = c("above"="#00ba38", "below"="#f8766d")) + 
  geom_text(color="white", size=2) +
  labs(title="Diverging Dot Plot", 
       subtitle="Normalized mileage from 'mtcars': Dotplot") + 
  ylim(-2.5, 2.5) +
  coord_flip()

##########################

# http://margintale.blogspot.in/2012/04/ggplot2-time-series-heatmaps.html
library(ggplot2)
library(plyr)
library(scales)
library(zoo)

# df <- read.csv("https://raw.githubusercontent.com/selva86/datasets/master/yahoo.csv")
# write.csv(df, file="yahoo.csv")
df <- read.csv("yahoo.csv")
df$date <- as.Date(df$date)  # format date
df <- df[df$year >= 2012, ]  # filter reqd years
# Create Month Week
df$yearmonth <- as.yearmon(df$date)
df$yearmonthf <- factor(df$yearmonth)
df <- ddply(df,.(yearmonthf), transform, monthweek=1+week-min(week))  # compute week number of month
df <- df[, c("year", "yearmonthf", "monthf", "week", "monthweek", "weekdayf", "VIX.Close")]
head(df)

# Plot
ggplot(df, aes(monthweek, weekdayf, fill = VIX.Close)) + 
  geom_tile(colour = "white") + 
  facet_grid(year~monthf) + 
  scale_fill_gradient(low="red", high="green") +
  labs(x="Week of Month",
       y="",
       title = "Time-Series Calendar Heatmap", 
       subtitle="Yahoo Closing Price", 
       fill="Close")

############################

library(ggplot2)
library(ggdendro)
theme_set(theme_bw())

hc <- hclust(dist(USArrests), "ave")  # hierarchical clustering
ggdendrogram(hc, rotate = TRUE, size = 2)

############################

# devtools::install_github("hrbrmstr/ggalt")
library(ggplot2)
library(ggalt)
library(ggfortify)
theme_set(theme_classic())

# Compute data with principal components ------------------
df <- iris[c(1, 2, 3, 4)]
pca_mod <- prcomp(df)  # compute principal components

# Data frame of principal components ----------------------
df_pc <- data.frame(pca_mod$x, Species=iris$Species)  # dataframe of principal components
df_pc_vir <- df_pc[df_pc$Species == "virginica", ]  # df for 'virginica'
df_pc_set <- df_pc[df_pc$Species == "setosa", ]  # df for 'setosa'
df_pc_ver <- df_pc[df_pc$Species == "versicolor", ]  # df for 'versicolor'

# Plot ----------------------------------------------------
ggplot(df_pc, aes(PC1, PC2, col=Species)) + 
  geom_point(aes(shape=Species), size=2) +   # draw points
  labs(title="Iris Clustering", 
       subtitle="With principal components PC1 and PC2 as X and Y axis",
       caption="Source: Iris") + 
  coord_cartesian(xlim = 1.2 * c(min(df_pc$PC1), max(df_pc$PC1)), 
                  ylim = 1.2 * c(min(df_pc$PC2), max(df_pc$PC2))) +   # change axis limits
  geom_encircle(data = df_pc_vir, aes(x=PC1, y=PC2)) +   # draw circles
  geom_encircle(data = df_pc_set, aes(x=PC1, y=PC2)) + 
  geom_encircle(data = df_pc_ver, aes(x=PC1, y=PC2))

##########################

