create procedure [dbo].[sp_GetPlot_Sea] as

declare @bin_image varbinary(max);
exec sp_execute_external_script  
@language =N'Python',  
@script=N'
import os
import tempfile
import matplotlib
import io
import numpy as np
import uuid
from scipy.stats import kendalltau
import seaborn as sns
sns.set(style="ticks")

rs = np.random.RandomState(11)
x = rs.gamma(2, size=1000)
y = -.5 * x + rs.normal(size=1000)

plt = sns.jointplot(x, y, kind="hex", stat_func=kendalltau, color="#4CB391")
tfi="C:\\TMP\\"+str(uuid.uuid4())+".png"
plt.savefig(tfi)
bin_image = open(tfi,"rb").read()
',
@params = N'@bin_image varbinary(max) OUTPUT',       
@bin_image = @bin_image OUTPUT;
select @bin_image as plot;
