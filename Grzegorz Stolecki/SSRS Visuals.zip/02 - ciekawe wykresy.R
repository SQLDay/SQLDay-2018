# Charge the vioplot library
library(vioplot)

# Create data
treatment=c(rep("A", 40) , rep("B", 40) , rep("C", 40) )
value=c( sample(2:5, 40 , replace=T) , sample(c(1:5,12:17), 40 , replace=T), sample(1:7, 40 , replace=T) )
data=data.frame(treatment,value)

# Draw the plot
with(data , vioplot( value[treatment=="A"] , value[treatment=="B"], value[treatment=="C"],  col=rgb(0.1,0.4,0.7,0.7) , names=c("A","B","C") ))

#############################

# library
library(ggridges)
library(ggplot2)

# Data
head(diamonds)

# basic example
ggplot(diamonds, aes(x = price, y = cut, fill = cut)) +
  geom_density_ridges() +
  theme_ridges() + 
  theme(legend.position = "none")

##############################

# library
library(igraph)
# data
head(mtcars)
# Make a correlation matrix:
mat=cor(t(mtcars[,c(1,3:6)]))
mat[mat<0.995]=0
# Make an Igraph object from this matrix:
network=graph_from_adjacency_matrix( mat, weighted=T, mode="undirected", diag=F)
plot(network)

# color palette
library(RColorBrewer)
coul = brewer.pal(nlevels(as.factor(mtcars$cyl)), "Set2")
# Map the color to cylinders
my_color=coul[as.numeric(as.factor(mtcars$cyl))]

# plot
par(bg="grey13", mar=c(0,0,0,0))
set.seed(4)
plot(network, 
     vertex.size=12,
     vertex.color=my_color, 
     vertex.label.cex=0.7,
     vertex.label.color="white",
     vertex.frame.color="transparent"
)
# title and legend
text(0,0,"The network chart of the mtcars dataset",col="white")
text(0.2,-0.1," - by the R graph gallery",col="white")
legend(x=-0.6, y=-0.12, legend=paste( levels(as.factor(mtcars$cyl)), " cylinders", sep=""), col = coul , bty = "n", pch=20 , pt.cex = 2, cex = 1, text.col="white" , horiz = T)

##################################

#Create data
name=c(3,10,10,3,6,7,8,3,6,1,2,2,6,10,2,3,3,10,4,5,9,10)
feature=paste("feature ", c(1,1,2,2,2,2,2,3,3,3,3,3,3,3,4,4,4,4,5,5,5,5) , sep="")
dat <- data.frame(name,feature)
dat <- with(dat, table(name, feature))
# Charge the circlize library
library(circlize)
# Make the circular plot
chordDiagram(as.data.frame(dat), transparency = 0.5)

##################################

# Packages
library(hexbin)
library(RColorBrewer)

# Create data
x <- rnorm(mean=1.5, 5000)
y <- rnorm(mean=1.6, 5000)

# Make the plot
bin<-hexbin(x, y, xbins=40)
my_colors=colorRampPalette(rev(brewer.pal(11,'Spectral')))
plot(bin, main="" , colramp=my_colors , legend=F ) 

###################################

library(fmsb)
data=as.data.frame(matrix( sample( 2:20 , 10 , replace=T) , ncol=10))
colnames(data)=c("math" , "english" , "biology" , "music" , "R-coding", "data-viz" , "french" , "physic", "statistic", "sport" )
data=rbind(rep(20,10) , rep(0,10) , data)
radarchart(data)
radarchart( data  , axistype=1 , 
            pcol=rgb(0.2,0.5,0.5,0.9) , pfcol=rgb(0.2,0.5,0.5,0.5) , plwd=4 , 
            cglcol="grey", cglty=1, axislabcol="grey", caxislabels=seq(0,20,5), cglwd=0.8,
            vlcex=0.8 
            
)

###################################

# Create data
names=c(rep("A", 80) , rep("B", 50) , rep("C", 70))
value=c( rnorm(80 , mean=10 , sd=9) , rnorm(50 , mean=2 , sd=15) , rnorm(70 , mean=30 , sd=10) )
data=data.frame(names,value)

# Basic boxplot
boxplot(data$value ~ data$names , col=terrain.colors(4) )

# Add data points
mylevels<-levels(data$names)
levelProportions<-summary(data$names)/nrow(data)

for(i in 1:length(mylevels)){
  
  thislevel<-mylevels[i]
  thisvalues<-data[data$names==thislevel, "value"]
  
  # take the x-axis indices and add a jitter, proportional to the N in each level
  myjitter<-jitter(rep(i, length(thisvalues)), amount=levelProportions[i]/2)
  points(myjitter, thisvalues, pch=20, col=rgb(0,0,0,.2)) 
  
}

################################

