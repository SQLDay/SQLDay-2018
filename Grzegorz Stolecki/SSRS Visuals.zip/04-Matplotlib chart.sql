USE [HelloPython]
GO
/****** Object:  StoredProcedure [dbo].[sp_GetPlot]    Script Date: 2017-08-14 20:54:23 ******/

create procedure [dbo].[sp_GetPlot] as

declare @bin_image varbinary(max);
exec sp_execute_external_script  
@language =N'Python',  
@script=N'
import os
import tempfile
import matplotlib
import io
import uuid
matplotlib.use("Agg")
import matplotlib.pyplot as plt
tfi="C:\\TMP\\"+str(uuid.uuid4())+".png"
plt.plot([1,2,1,2])
plt.savefig(tfi)
bin_image = open(tfi,"rb").read()
',
@params = N'@bin_image varbinary(max) OUTPUT',       
@bin_image = @bin_image OUTPUT;
select @bin_image as plot;
