-- This scrips demonstrates the necessity of initiating
-- loop variables on each iteration.
DECLARE @i int = 5

WHILE @i > 0
BEGIN
   DECLARE @j int -- = NULL
   SELECT @j = isnull(@j, 0) + @i
   SELECT @j
   SELECT @i = @i - 1
END
