USE Profiler
GO

SELECT Duration/1000 AS Duration_MS, CPU, Reads, StartTime, EndTime, TextData 
FROM fwDays
WHERE EventClass = 10
	AND TextData NOT LIKE 'exec sp_reset_connection'
	AND TransactionID IS NULL

SELECT SUM(Duration)/1000 AS Duration_MS, SUM(CPU) AS CPU, SUM(Reads) AS Reads, 
		MIN(StartTime) AS TransactionStartTime, MAX(EndTime) AS TransactionEndTime
FROM fwDays
WHERE EventClass = 10
	AND TextData NOT LIKE 'exec sp_reset_connection'
	AND TransactionID IS NOT NULL
GROUP BY TransactionID
