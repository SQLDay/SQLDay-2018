﻿using ORMvsSQL.Queries;
using System;
using System.Configuration;

namespace ORMvsSQL
{
    class Program
    {
        static void Main(string[] args)
        {
            var soConnectionString = ConfigurationManager.ConnectionStrings["StackOverflow_Old"].ConnectionString;
            var twitterConnectionString = ConfigurationManager.ConnectionStrings["Twitter"].ConnectionString;
            var userId = 1;

            while (1 == 1)
            {
                Console.WriteLine("Choose the operation:");
                Console.WriteLine("1. Simple Query:");
                Console.WriteLine("2. Column List:");
                Console.WriteLine("3. Lazy Load:");
                Console.WriteLine("4. Data Types:");
                Console.WriteLine("5. Data Modification:");
                Console.WriteLine("6. Complex Query:");
                Console.WriteLine("7. Parameter Sniffing:");
                Console.WriteLine("0. Exit:");

                switch (Console.ReadKey().KeyChar)
                {
                    case '1':
                        SimpleQueries.GetUser_EF(userId);
                        SimpleQueries.GetUser_ADO(userId, soConnectionString);
                        SimpleQueries.GetUser_Dapper(userId, soConnectionString);
                        break;
                    case '2':
                        var posts = Columns.GetUserPosts(userId);
                        foreach(var post in posts)
                        {
                            Console.WriteLine($"Title: {post.Title} | AnswerCount: {post.AnswerCount}");
                        }

                        Console.ReadLine();
                        var postsLight = Columns.GetUserPosts(userId, soConnectionString);
                        foreach (var post in postsLight)
                        {
                            Console.WriteLine($"Title: {post.Title} | AnswerCount: {post.AnswerCount}");
                        }

                        Console.ReadLine();
                        break;
                    case '3':
                        LazyLoad.PrintUserPosts(userId);
                        Console.ReadLine();
                        LazyLoad.PrintUserPosts(userId, soConnectionString);
                        Console.ReadLine();
                        LazyLoad.PrintUserPostsInclude(userId);
                        Console.ReadLine();
                        LazyLoad2.PrintPostsUsers_EF();
                        Console.ReadLine();
                        LazyLoad2.PrintPostsUsers(soConnectionString);
                        Console.ReadLine();
                        LazyLoad2.PrintUserPosts_EF_Include();
                        Console.ReadLine();
                        break;
                    case '4':
                        DataTypes.GetUser("Brent Ozar");
                        Console.ReadLine();
                        DataTypes.GetUser("Brent Ozar", twitterConnectionString);
                        Console.ReadLine();
                        break;
                    case '5':
                        Update.UpdateUserStatuses("Pinal Dave");
                        Console.ReadLine();
                        Update.UpdateUserStatuses("Pinal Dave", twitterConnectionString);
                        Console.ReadLine();
                        break;
                    case '6':
                        ComplexQuery.GetCustomers("Computer Store", "Delivery Van", DateTime.Parse("01-01-2015"), 1);
                        Console.ReadLine();
                        break;
                    case '7':
                        ParameterSniffing.GetUserStatuses("B");
                        ParameterSniffing.GetUserStatuses("Y");
                        Console.ReadLine();
                        break;
                    case '0':
                        return;
                }

                Console.WriteLine();
                Console.WriteLine("***********************************************************************************");
                Console.WriteLine();
            }
        }
    }
}
 