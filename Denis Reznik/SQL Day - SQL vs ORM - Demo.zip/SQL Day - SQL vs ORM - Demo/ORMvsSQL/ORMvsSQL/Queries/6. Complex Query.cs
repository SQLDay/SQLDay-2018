﻿using Dapper;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class ComplexQuery
    {
        public static void GetCustomers(string customerCategory, string deliveryMethod, DateTime date, int orderLineCount)
        {
            using (var context = new WideWorldImportersEntities())
            {
                var customers = context.Customers.Where(c => c.CustomerCategory.CustomerCategoryName == customerCategory)
                    .Where(c => c.DeliveryMethod.DeliveryMethodName == deliveryMethod)
                    .Where(c => c.CustomerID == c.BillToCustomerID)
                    .Where(c => c.Orders.Where(o => o.OrderDate > date && o.OrderLines.Count > orderLineCount).Any())
                    .OrderBy(c => c.CustomerName)
                    .Select(c => new { Id = c.CustomerID, Name = c.CustomerName })
                    .Distinct()
                    .ToList();

                foreach(var customer in customers)
                {
                    Console.WriteLine($"Id: {customer.Id} | Name: {customer.Name}");
                }
            }
        }

        public static void PrintUserPosts(int userId, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var posts = connection.Query<dynamic>(
                        "SELECT u.DisplayName, p.Title FROM Users u " +
                        "INNER JOIN Posts p " +
                            "ON u.Id = p.OwnerUserId " +
                        "WHERE u.Id = @UserId", 
                        new { UserId = userId }
                    ).ToList();

                Console.WriteLine($"User: {posts.First().DisplayName}");
                Console.WriteLine("Posts: ");
                foreach (var post in posts)
                {
                    Console.WriteLine($"Title: {post.Title}");
                }
            }
        }

        public static void PrintUserPostsInclude(int userId)
        {
            using (var context = new StackOverflow_OldEntities())
            {
                var user = context.Users.Include("Posts").Where(u => u.Id == userId).Single();
                Console.WriteLine($"User: {user.DisplayName}");
                Console.WriteLine("Posts: ");
                foreach (var post in user.Posts)
                {
                    Console.WriteLine(post.Title);
                }
            }
        }
    }
}
