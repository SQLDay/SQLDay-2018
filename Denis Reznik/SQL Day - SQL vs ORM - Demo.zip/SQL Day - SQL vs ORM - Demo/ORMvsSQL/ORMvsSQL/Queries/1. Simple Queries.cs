﻿using Dapper;
using System.Data.SqlClient;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class SimpleQueries
    {
        public static User GetUser_ADO(int userId, string connectionString)
        {
            var user = new User();
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SELECT * FROM Users WHERE Id = @Id", connection);
                command.Parameters.AddWithValue("@Id", userId);
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        user = new User
                        {
                            Id = reader.GetInt32(0),
                            Reputation = reader.GetInt32(1),
                            CreationDate = reader.GetDateTime(2),
                            DisplayName = reader.GetString(3),
                            LastAccessDate = reader.GetDateTime(4),
                            WebsiteUrl = reader.GetString(5),
                            Location = reader.GetString(6),
                            AboutMe = reader.GetString(7),
                            Views = reader.GetInt32(8),
                            UpVotes = reader.GetInt32(9),
                            DownVotes = reader.GetInt32(10),
                            AccountId = reader.GetInt32(11),
                            ProfileImageUrl = reader.GetString(12),
                            Age = reader.GetByte(13)
                        };
                    }
                }
            }

            return user;
        }

        public static User GetUser_EF(int userId)
        {
            using (var context = new StackOverflow_OldEntities())
            {
                return context.Users.Where(u => u.Id == userId).Single();
            }
        }

        public static dynamic GetUser_Dapper(int userId, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                return connection.Query<dynamic>("SELECT * FROM Users WHERE Id = @Id", 
                    new { Id = userId }).Single();
            }
        }
    }
}
