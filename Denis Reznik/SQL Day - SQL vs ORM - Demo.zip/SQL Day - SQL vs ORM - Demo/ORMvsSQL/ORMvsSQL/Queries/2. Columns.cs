﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORMvsSQL.Queries
{
    public class Columns
    {
        public static IList<Post> GetUserPosts(int userId)
        {
            using (var context = new StackOverflow_OldEntities())
            {
                return context.Posts.Where(p => p.OwnerUserId == userId).ToList();
            }
        }

        public static IList<dynamic> GetUserPosts(int userId, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                return connection.Query<dynamic>(
                        "SELECT Title, AnswerCount FROM Posts " +
                        "WHERE OwnerUserId = @UserId", 
                        new { UserId = userId }
                    ).ToList();
            }
        }
    }
}
