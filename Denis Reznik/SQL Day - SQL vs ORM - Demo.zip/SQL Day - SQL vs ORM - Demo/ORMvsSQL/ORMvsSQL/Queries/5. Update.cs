﻿using Dapper;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class Update
    {
        public static void UpdateUserStatuses(string name)
        {
            using (var context = new TwitterEntities())
            {
                var user = context.TwitterUsers.Include("Statuses").Where(u => u.name.StartsWith(name)).Single();
                foreach(var status in user.Statuses)
                {
                    status.cached_date = DateTime.UtcNow;
                }

                context.SaveChanges();
            }
        }

        public static void UpdateUserStatuses(string name, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Execute(
                        "UPDATE Statuses SET cached_date = GETUTCDATE() " +
                        "WHERE user_id = (SELECT id FROM Users WHERE name = @Name)", 
                        new { Name = name }
                    );
            }
        }
    }
}
