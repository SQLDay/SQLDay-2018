﻿using System.Collections.Generic;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class ParameterSniffing
    {
        public static IList<TwitterStatus> GetUserStatuses(string nameStartPattern)
        {
            using (var context = new TwitterEntities())
            {
                return context.Statuses.Where(s => s.User.name.StartsWith(nameStartPattern)).ToList();
            }
        }
    }
}
