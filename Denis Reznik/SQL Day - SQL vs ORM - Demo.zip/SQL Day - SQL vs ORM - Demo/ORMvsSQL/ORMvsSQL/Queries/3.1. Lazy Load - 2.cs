﻿using Dapper;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class LazyLoad2
    {
        public static void PrintPostsUsers_EF()
        {
            using (var context = new StackOverflow_OldEntities())
            {
                var posts = context.Posts.Where(p => p.OwnerUserId != null).Take(2000).ToList();
                foreach(var post in posts)
                {
                    Console.WriteLine(post.User.DisplayName);
                }
            }
        }

        public static void PrintPostsUsers(string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var posts = connection.Query<dynamic>(
                        @"SELECT TOP(2000) u.DisplayName AS UserDisplayName
                        FROM Posts p
                        INNER JOIN Users u
                            ON p.OwnerUserId = u.Id"
                    ).ToList();

                foreach (var post in posts)
                {
                    Console.WriteLine($"Title: {post.UserDisplayName}");
                }
            }
        }

        public static void PrintUserPosts_EF_Include()
        {
            using (var context = new StackOverflow_OldEntities())
            {
                var posts = context.Posts.Include("User").Where(p => p.OwnerUserId != null).Take(2000).ToList();
                foreach (var post in posts)
                {
                    Console.WriteLine(post.User.DisplayName);
                }
            }
        }
    }
}
