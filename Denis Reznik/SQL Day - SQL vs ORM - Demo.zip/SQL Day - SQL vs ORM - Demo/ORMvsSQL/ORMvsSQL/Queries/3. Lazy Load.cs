﻿using Dapper;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class LazyLoad
    {
        public static void PrintUserPosts(int userId)
        {
            using (var context = new StackOverflow_OldEntities())
            {
                var user = context.Users.Where(u => u.Id == userId).Single();
                Console.WriteLine($"User: {user.DisplayName}");
                Console.WriteLine("Posts: ");
                foreach(var post in user.Posts)
                {
                    Console.WriteLine(post.Title);
                }
            }
        }

        public static void PrintUserPosts(int userId, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var user = connection.Query<dynamic>(
                        "SELECT u.* FROM Users u " +
                        "WHERE u.Id = @UserId",
                        new { UserId = userId }
                    ).Single();

                var posts = connection.Query<dynamic>(
                        "SELECT p.* FROM Posts p " +
                        "WHERE p.OwnerUserId = @UserId", 
                        new { UserId = userId }
                    ).ToList();

                Console.WriteLine($"User: {user.DisplayName}");
                Console.WriteLine("Posts: ");
                foreach (var post in posts)
                {
                    Console.WriteLine($"Title: {post.Title}");
                }
            }
        }

        public static void PrintUserPostsInclude(int userId)
        {
            using (var context = new StackOverflow_OldEntities())
            {
                var user = context.Users.Include("Posts").Where(u => u.Id == userId).Single();
                Console.WriteLine($"User: {user.DisplayName}");
                Console.WriteLine("Posts: ");
                foreach (var post in user.Posts)
                {
                    Console.WriteLine(post.Title);
                }
            }
        }
    }
}
