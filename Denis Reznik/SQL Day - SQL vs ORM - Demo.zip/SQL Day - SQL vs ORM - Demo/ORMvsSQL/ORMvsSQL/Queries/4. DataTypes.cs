﻿using Dapper;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace ORMvsSQL.Queries
{
    public class DataTypes
    {
        public static void GetUser(string name)
        {
            using (var context = new TwitterEntities())
            {
                var user = context.TwitterUsersVs.Where(u => u.name.StartsWith(name)).Single();
                Console.WriteLine($"User: {user.name}");
                Console.WriteLine($"Location: {user.location}");
            }
        }

        public static void GetUser(string name, string connectionString)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var user = connection.Query<dynamic>(
                        "SELECT name, location FROM UsersV u " +
                        "WHERE u.name LIKE @Name + '%'", 
                        new { Name = name }
                    ).Single();

                Console.WriteLine($"User: {user.name}");
                Console.WriteLine($"Location: {user.location}");
            }
        }
    }
}
