USE AdventureWorks2014
GO

-- Cleanup
DROP INDEX IX_BIGPRODUCT_NAME
ON [dbo].[bigProduct]
GO

ALTER TABLE [dbo].[bigProduct]
	ALTER COLUMN Name nvarchar(80)
GO