USE Twitter
GO

SELECT * FROM UsersV u
WHERE u.name = N'Brent Ozar'

SELECT * FROM UsersV u
WHERE u.name = 'Brent Ozar'


USE StackOverflow_Old
GO

SELECT * FROM UsersV u
WHERE u.DisplayName = N'Denis Reznik'

SELECT * FROM UsersV u
WHERE u.DisplayName = 'Denis Reznik'

