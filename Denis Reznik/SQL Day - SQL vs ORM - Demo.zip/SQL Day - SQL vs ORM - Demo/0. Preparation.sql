USE [StackOverflow_Old]
GO

/****** Object:  Index [IX_POSTS_OWNERUSERID]    Script Date: 3/23/2017 12:28:25 AM ******/
CREATE NONCLUSTERED INDEX [IX_POSTS_OWNERUSERID_2] ON [dbo].[Posts]
(
	[OwnerUserId] ASC
)
INCLUDE (Title, AnswerCount) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO


ALTER TABLE Posts
	ADD CONSTRAINT FK_POSTS_OWNERUSERID FOREIGN KEY (OwnerUserId) REFERENCES Users (Id)
GO

SELECT OwnerUserId, COUNT(*) FROM Posts
WHERE OwnerUserId NOT IN (SELECT Id FROM Users)
GROUP BY OwnerUserId
ORDER BY COUNT(*) DESC

BEGIN TRAN

UPDATE Posts SET OwnerUserId = NULL
WHERE OwnerUserId IN (2253640, 2714897)

-- COMMIT


ALTER TABLE Posts
	ADD CONSTRAINT FK_POSTS_OWNERUSERID FOREIGN KEY (OwnerUserId) REFERENCES Users (Id)
GO

CREATE TABLE [dbo].[UsersV](
	[Id] [int] NOT NULL,
	[Reputation] [int] NULL,
	[CreationDate] [datetime] NULL,
	[DisplayName] [varchar](255) NULL,
	[LastAccessDate] [datetime] NULL,
	[WebsiteUrl] [varchar](1000) NULL,
	[Location] [varchar](255) NULL,
	[AboutMe] [varchar](max) NULL,
	[Views] [int] NULL,
	[UpVotes] [int] NULL,
	[DownVotes] [int] NULL,
	[AccountId] [int] NULL,
	[ProfileImageUrl] [varchar](1000) NULL,
	[Age] [tinyint] NULL,
	CONSTRAINT [PK_USERSV] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)
)
GO

INSERT INTO UsersV
SELECT * FROM Users
GO

CREATE NONCLUSTERED INDEX IX_USERSV_DISPLAYNAME ON UsersV
(
	[DisplayName]
)
GO

