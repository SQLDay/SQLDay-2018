/*============================================================================
	File:		0010 - Preparation of demo database.sql

	Summary:	This script creates a database for all following demonstration
				scripts!
				THIS SCRIPT IS PART OF THE TRACK: "DAILY Index problems"

	Date:		Dezember 2015

	SQL Server Version: 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

IF DB_ID(N'CustomerOrders') IS NOT NULL
BEGIN
	ALTER DATABASE CustomerOrders SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE CustomerOrders;
END
GO

DECLARE	@DataPath	NVARCHAR(256) = CAST(SERVERPROPERTY('InstanceDefaultDataPath') AS NVARCHAR(256)) + N'CustomerOrders.mdf';
DECLARE @LogPath	NVARCHAR(256) = CAST(SERVERPROPERTY('InstanceDefaultLogPath') AS NVARCHAR(256)) + N'CustomerOrders.ldf';

RESTORE DATABASE CustomerOrders
FROM DISK = N'S:\Backup\CustomerOrders.bak'
WITH
	MOVE N'CustomerOrders_Data' TO @DataPath,
	MOVE N'CustomerOrders_Log' TO @LogPath,
	STATS = 10,
	REPLACE,
	RECOVERY;
GO

ALTER AUTHORIZATION ON DATABASE::CustomerOrders TO sa;
ALTER DATABASE CustomerOrders SET RECOVERY SIMPLE;
GO

RAISERROR ('Database %s will be created...', 0, 1, 'demo_db') WITH NOWAIT;
IF DB_ID('demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE [demo_db] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [demo_db];
END
GO

CREATE DATABASE [demo_db]
GO
ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;
ALTER DATABASE [demo_db] SET RECOVERY SIMPLE;
ALTER DATABASE [demo_db] SET AUTO_CREATE_STATISTICS ON; 
ALTER DATABASE [demo_db] SET AUTO_UPDATE_STATISTICS ON; 
ALTER DATABASE [demo_db] SET AUTO_UPDATE_STATISTICS_ASYNC OFF;
GO

RAISERROR ('Database %s has been created...', 0, 1, 'demo_db') WITH NOWAIT;
