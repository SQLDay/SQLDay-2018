/*============================================================================
	File:		0060 - ranking of data types.sql

	Summary:	This script creates a table with different data types to check
				the execution plan! Although the execution plan is showing a
				SEEK operation it is a SCAN in behind!

	WebLink:	http://db-berater.blogspot.de/2014/11/rangfolge-von-datentypen-auswirkung-auf.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL
	DROP TABLE dbo.Orders;
	GO

SELECT	Id,
		Customer_Id,
		CAST(ROW_NUMBER() OVER (ORDER BY OrderNumber) AS NVARCHAR(10)) AS OrderNumber,
		InvoiceNumber,
		OrderDate,
		OrderStatus_Id,
		Employee_Id
INTO	dbo.Orders
FROM	CustomerOrders.dbo.CustomerOrders;
GO

CREATE UNIQUE INDEX nix_Orders_OrderNumber
ON dbo.Orders (OrderNumber)
INCLUDE
(Customer_Id, OrderDate, InvoiceNumber);
GO

SET STATISTICS IO ON;
GO

SELECT Id, Customer_Id, OrderNumber, InvoiceNumber, OrderDate
FROM dbo.Orders
WHERE OrderNumber  = 10275;
GO

-- new QO (>= SQL 2014) consider the wrong data type
-- when it is the same "nature"!
SELECT Id, Customer_Id, OrderNumber, InvoiceNumber, OrderDate
FROM dbo.Orders
WHERE OrderNumber  = '10275';
GO

SELECT Id, Customer_Id, OrderNumber, InvoiceNumber, OrderDate
FROM dbo.Orders
WHERE OrderNumber  = N'10275';
GO

-- precedence of data types in Microsoft SQL Server!
http://msdn.microsoft.com/en-us/library/ms190309.aspx

-- clean the kitchen
IF OBJECT_ID('dbo.Orders', 'U') IS NOT NULL
	DROP TABLE dbo.Orders;
	GO
