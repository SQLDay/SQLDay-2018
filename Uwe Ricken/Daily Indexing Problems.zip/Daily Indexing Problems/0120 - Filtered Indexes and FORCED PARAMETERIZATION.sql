/*============================================================================
	File:		0120 - Filtered Indexes and FORCED PARAMETERIZATION.sql

	Summary:	This demo script shows the impact of the database setting
				PARAMETRIZATION and it's sidekicks when filtered indexes
				must be used.

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Troubleshooting"

	Date:		May 2018

	SQL Server Version: 2012 / 2014 / 2016 / 2017
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- Create the demo 
IF DB_ID(N'demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE [demo_db] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [demo_db];
END
GO

CREATE DATABASE [demo_db];
ALTER DATABASE [demo_db] SET RECOVERY SIMPLE;
ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;
ALTER DATABASE [demo_db] SET PARAMETERIZATION FORCED;
GO

-- Fill the demo table with data
SELECT	*
INTO	[demo_db].dbo.CustomerOrders
FROM	CustomerOrders.dbo.CustomerOrders;
GO

USE [demo_db];
GO

-- Create a filtered index on the customer_id attribute
CREATE NONCLUSTERED INDEX nix_CustomerOrders_Customer_Id
ON dbo.CustomerOrders (Customer_Id)
INCLUDE
(
	OrderNumber,
	OrderDate
)
WHERE	Customer_Id = 10;
GO

-- ACTIVATE the execution plan and see what index is used!
SET STATISTICS IO, TIME ON;
GO

SELECT	Customer_Id,
		OrderNumber,
		OrderDate
FROM	dbo.CustomerOrders
WHERE	Customer_id = 10;
GO

SET STATISTICS IO, TIME OFF;
GO

-- compare the database settings of all user databases
SELECT	name,
		compatibility_level,
		collation_name,
		is_read_only,
		is_auto_close_on,
		is_auto_shrink_on,
		is_parameterization_forced,
		is_read_committed_snapshot_on
FROM	sys.databases
WHERE	database_id > 4;
GO

-- Change the settings of the database
ALTER DATABASE [demo_db] SET PARAMETERIZATION SIMPLE;
GO

-- and rerun the query!
SET STATISTICS IO, TIME ON;
GO

SELECT	Customer_Id,
		OrderNumber,
		OrderDate
FROM	dbo.CustomerOrders
WHERE	Customer_id = 10;
GO

SET STATISTICS IO, TIME OFF;
GO