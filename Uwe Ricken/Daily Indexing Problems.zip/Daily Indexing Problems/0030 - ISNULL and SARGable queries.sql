/*============================================================================
	File:		0030 - ISNULL and SARGable queries.sql

	Summary:	This script creates two tables with the same structure to
				store actual data and historical data (partitioning).
				The query will always use both tables although data are
				only expected in ONE table!

	WebLink:	http://db-berater.blogspot.de/2014/08/isnull-als-predikat-seek-oder-scan.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

-- Create the demo tables!
IF OBJECT_ID('dbo.Addresses_PROD', 'U') IS NOT NULL
	DROP TABLE dbo.Addresses_PROD;
	GO

IF OBJECT_ID('dbo.Addresses_TEST', 'U') IS NOT NULL
	DROP TABLE dbo.Addresses_TEST;
	GO

CREATE TABLE dbo.Addresses_PROD
(
	Id		INT				NOT NULL,
	Street	VARCHAR(128)	NOT NULL,
	CCode	CHAR(3)			NULL,
	ZIP		CHAR(5)			NOT NULL,
	City	VARCHAR(128)	NOT NULL,
	State	VARCHAR(128)	NOT NULL,

	CONSTRAINT pk_Addresses_PROD
	PRIMARY KEY CLUSTERED (Id)
);
GO

CREATE TABLE dbo.Addresses_TEST
(
	Id		INT				NOT NULL,
	Street	VARCHAR(128)	NOT NULL,
	CCode	CHAR(3)			NOT NULL,
	ZIP		CHAR(5)			NOT NULL,
	City	VARCHAR(128)	NOT NULL,
	State	VARCHAR(128)	NOT NULL,

	CONSTRAINT pk_Addresses_TEST
	PRIMARY KEY CLUSTERED (Id)
);
GO

BEGIN TRANSACTION;
GO
	INSERT INTO dbo.Addresses_PROD WITH (TABLOCK)
	SELECT * FROM CustomerOrders.dbo.Addresses;
	GO

	INSERT INTO dbo.Addresses_TEST WITH (TABLOCK)
	SELECT * FROM CustomerOrders.dbo.Addresses;
	GO
COMMIT TRANSACTION;
GO

SELECT * FROM dbo.Addresses_PROD;
SELECT * FROM dbo.Addresses_TEST;
GO

-- For better query power an additional index will be set on CCode
CREATE INDEX ix_Addresses_PROD_CCode ON dbo.Addresses_PROD (CCode) INCLUDE (ZIP);
CREATE INDEX ix_Addresses_TEST_CCode ON dbo.Addresses_TEST (CCode) INCLUDE (ZIP);
GO

SET STATISTICS IO ON;
GO

DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(5);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.Addresses_TEST
WHERE	ISNULL(CCode, 'POL') = 'POL';
GO

DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(5);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.Addresses_PROD
WHERE	ISNULL(CCode, 'POL') = 'POL';
GO

-- make the action visible!
SELECT Id, CCode, ZIP FROM dbo.Addresses_TEST WHERE ISNULL(CCode, 'POL') = 'POL'
OPTION (QUERYTRACEON 9130);
SELECT Id, CCode, ZIP FROM dbo.Addresses_PROD WHERE ISNULL(CCode, 'POL') = 'POL'
OPTION (QUERYTRACEON 9130);
GO

-- Solution
DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(5);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.Addresses_TEST WHERE ISNULL(CCode, 'POL') = 'POL';
GO

DECLARE @Id INT;
DECLARE @CCode CHAR(3);
DECLARE @ZIP CHAR(5);

SELECT	@Id = Id,
		@CCode = CCode,
		@ZIP = ZIP
FROM	dbo.Addresses_PROD
WHERE	CCode IS NULL OR
		CCode = 'POL';

SELECT	Id,
		CCode,
		ZIP
FROM	dbo.Addresses_PROD
WHERE	CCode IS NULL

UNION ALL

SELECT	Id,
		CCode,
		ZIP
FROM	dbo.Addresses_PROD
WHERE	CCode = 'POL';
GO

SET STATISTICS IO OFF;
GO

-- Clean the kitchen
DROP TABLE dbo.Addresses_PROD;
DROP TABLE dbo.Addresses_TEST;
GO
