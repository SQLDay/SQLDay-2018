/*============================================================================
	File:		0110 - Dont delete indexes because they are not used.sql

	Summary:	This script demonstrates the influence of not used indexes
				to the performance of queries!

				EXPRESSION OF THANKS to Rob Farley (@rob_farley)
				https://sqlperformance.com/2016/10/sql-plan/implementing-custom-sort

	WebLink:	none

	Date:		August 2017

	SQL Server Version: 2008 / 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- Create the demo 
IF DB_ID(N'demo_db') IS NOT NULL
BEGIN
	ALTER DATABASE [demo_db] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE [demo_db];
END
GO

CREATE DATABASE [demo_db];
ALTER DATABASE [demo_db] SET RECOVERY SIMPLE;
ALTER AUTHORIZATION ON DATABASE::demo_db TO sa;
ALTER DATABASE [demo_db] SET PARAMETERIZATION FORCED;
GO

USE demo_db;
GO

BEGIN TRANSACTION;
GO
	SELECT	*
	INTO	dbo.Articles
	FROM	CustomerOrders.dbo.Articles;
	GO

	SELECT	*
	INTO	dbo.CustomerOrderDetails
	FROM	CustomerOrders.dbo.CustomerOrderDetails;
	GO
COMMIT TRANSACTION;
GO

/* Prepare the affected tables in the demo databases and create indexes for the demo */
CREATE UNIQUE CLUSTERED INDEX cuix_Articles_Id
ON dbo.Articles (Id);
GO

CREATE UNIQUE NONCLUSTERED INDEX nuix_Articles_Name
ON dbo.Articles (Name);
GO

CREATE NONCLUSTERED INDEX nix_CustomerOrderDetails_Article_Id
ON dbo.CustomerOrderDetails (Article_Id)
INCLUDE
(
	Quantity,
	Price
);
GO

SET NOCOUNT ON;
SET STATISTICS IO, TIME ON;
GO

SELECT	DISTINCT
		A.name,
		SUM(COD.Quantity * COD.Price)	AS	Total
FROM	dbo.Articles AS A
		INNER JOIN dbo.CustomerOrderDetails AS COD
		ON (A.Id = COD.Article_Id)
GROUP BY
		A.Name
OPTION	(MAXDOP 1);
GO

SELECT	DISTINCT
		A.name,
		CAST(SUM(COD.Quantity * COD.Price) AS NUMERIC(10, 2))	AS	Total
FROM	dbo.Articles AS A
		INNER JOIN dbo.CustomerOrderDetails AS COD
		ON (A.Id = COD.Article_Id)
GROUP BY
		A.Name;
GO

SELECT	I.index_id,
		I.name,
		DDIUS.user_scans,
		DDIUS.user_seeks,
		DDIUS.user_lookups
FROM	sys.indexes AS I
		LEFT JOIN sys.dm_db_index_usage_stats AS DDIUS
		ON
		(
			I.object_id = DDIUS.object_id
			AND I.index_id = DDIUS.index_id
		)
WHERE	I.object_id = OBJECT_ID(N'dbo.Articles', N'U')
ORDER BY
		I.index_id;;
GO

DROP INDEX nuix_Articles_Name
ON dbo.Articles
GO

SELECT	DISTINCT
		A.name,
		SUM(COD.Quantity * COD.Price)	AS	Total
FROM	dbo.Articles AS A
		INNER JOIN dbo.CustomerOrderDetails AS COD
		ON (A.Id = COD.Article_Id)
GROUP BY
		A.Name;
GO

-- Clean the kitchen
DROP INDEX nix_CustomerOrderDetails_Article_Id ON dbo.CustomerOrderDetails;
DROP INDEX nuix_Articles_Name ON dbo.Articles;
DROP INDEX cuix_Articles_Id ON dbo.Articles;
