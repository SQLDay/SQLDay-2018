/*============================================================================
	File:		0020 - Problem with PARTITIONED VIEWS.sql

	Summary:	This script creates two tables with the same structure to
				store actual data and historical data (partitioning).
				The query will always use both tables although data are
				only expected in ONE table!

	WebLink:	http://db-berater.blogspot.de/2013/07/optimierung-von-partitioned-views.html

	Date:		Dezember 2015

	SQL Server Version: 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
USE demo_db;
GO

IF OBJECT_ID(N'dbo.ActualOrders', N'U') IS NOT NULL
	DROP TABLE dbo.ActualOrders;
	GO

IF OBJECT_ID(N'dbo.HistoricOrders', N'U') IS NOT NULL
	DROP TABLE dbo.HistoricOrders;
	GO

/************************** create a demo environment from CustomerOrders *********/
BEGIN TRANSACTION;
GO
	-- create 1,000,000 rows for the historical data 
	SELECT	CAST(Id AS BIGINT)	AS	Id,
			Customer_Id ,
			OrderNumber ,
			InvoiceNumber ,
			OrderDate ,
			OrderStatus_Id ,
			Employee_Id ,
			InsertUser ,
			InsertDate
	INTO	dbo.HistoricOrders
	FROM	CustomerOrders.dbo.CustomerOrders;
	GO

	-- now we create ~200,000 rows for the actual data
	SELECT	ROW_NUMBER() OVER (ORDER BY Id)	+ 1000000 AS	Id ,
			Customer_Id,
			OrderNumber,
			InvoiceNumber,
			DATEADD(YEAR, 3, OrderDate)	AS	OrderDate,
			OrderStatus_Id,
			Employee_Id,
			InsertUser,
			InsertDate
	INTO	dbo.ActualOrders			
	FROM	dbo.HistoricOrders
	WHERE	OrderDate >= '20130101';
	GO
COMMIT TRANSACTION;
GO

-- Create a partitioned view for all orders
IF OBJECT_ID(N'dbo.AllOrders', N'V') IS NOT NULL
	DROP VIEW dbo.AllOrders;
	GO

CREATE VIEW dbo.AllOrders
AS
	SELECT	Id,
			Customer_Id,
			OrderNumber,
			InvoiceNumber,
			OrderDate,
			OrderStatus_Id,
			Employee_Id,
			InsertUser,
			InsertDate
	FROM	dbo.HistoricOrders

	UNION ALL

	SELECT	Id,
			Customer_Id,
			OrderNumber,
			InvoiceNumber,
			OrderDate,
			OrderStatus_Id,
			Employee_Id,
			InsertUser,
			InsertDate
	FROM	dbo.ActualOrders;
GO

-- Testquery 1:	All orders in 2014
SET STATISTICS IO ON;
GO

SELECT	*
FROM	dbo.AllOrders AS A
WHERE	A.OrderDate >= '20170101' AND
		A.OrderDate < '20170201'
GO

-- Testquery 2: All orders from all affected tables
SELECT	*
FROM	dbo.ActualOrders AS A
WHERE	A.OrderDate >= '20170101' AND
		A.OrderDate < '20170201'

UNION ALL

SELECT	*
FROM	dbo.HistoricOrders AS H
WHERE	H.OrderDate >= '20170101' AND
		H.OrderDate < '20170201'
GO

-- we create a clustered index on the orderdate because this attribute is
-- mostly used in this scenario. Keep in mind the UNIQUIFIER if your 
-- clustered index is not UNIQUE!
CREATE CLUSTERED INDEX cuix_HistoricData_OrderDate
ON dbo.HistoricOrders (OrderDate);
GO

CREATE CLUSTERED INDEX cuix_ActualData_OrderDate
ON dbo.ActualOrders (OrderDate);
GO

SELECT	*
FROM	dbo.AllOrders AS A
WHERE	A.OrderDate >= '20170101' AND
		A.OrderDate < '20170201'
GO


SELECT MAX(OrderDate) FROM dbo.HistoricOrders;
SELECT MIN(OrderDate) FROM dbo.ActualOrders;
GO

ALTER TABLE dbo.HistoricOrders
ADD CONSTRAINT chk_OrderDate_Historic CHECK (OrderDate < '2016-01-01');
GO

ALTER TABLE dbo.ActualOrders
ADD CONSTRAINT chk_OrderDate_Actual CHECK (OrderDate >= '2016-01-01');
GO

SELECT	*
FROM	dbo.AllOrders AS A
WHERE	A.OrderDate >= '20170101' AND
		A.OrderDate < '20170201'
GO