/*============================================================================
	File:		0100 - ORDER BY CASE WHEN.sql

	Summary:	This script demonstrates an ORDER BY operation with an option
				to prevent the expensive SORT-operator in the execution plan!

				EXPRESSION OF THANKS to Rob Farley (@rob_farley)
				https://sqlperformance.com/2016/10/sql-plan/implementing-custom-sort

	WebLink:	none

	Date:		November 2016

	SQL Server Version: 2008 / 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

CREATE UNIQUE CLUSTERED INDEX cuix_Addresses_Id ON dbo.Addresses (Id);
CREATE NONCLUSTERED INDEX nix_Addresses_CCode ON dbo.Addresses (CCode);
GO

SELECT * FROM dbo.Addresses
ORDER BY
	CASE WHEN CCode LIKE 'Y%'
		 THEN 1
		 ELSE 2
	END
GO

SELECT	A.*
FROM	dbo.Addresses AS A
CROSS APPLY
(SELECT CASE WHEN A.CCode LIKE 'Y%'
		 THEN 1
		 ELSE 2
	END AS OrderingCol
) AS O
ORDER BY
	O.OrderingCol, CCode;
GO

SET STATISTICS IO, TIME ON;
GO


SELECT R.Id, R.CCode, R.OrderCol
FROM
(
	SELECT Id, Street, CCode, ZIP, City, State, 1 AS OrderCol
	FROM	dbo.Addresses WHERE CCode = 'YEM'

	UNION ALL

	SELECT Id, Street, CCode, ZIP, City, State, 2 AS OrderCol
	FROM	dbo.Addresses WHERE CCode <> 'YEM'
) AS R
ORDER BY
		R.OrderCol, CCode;
GO

SELECT	Id, CCode
FROM	dbo.Addresses
ORDER BY
		CASE WHEN CCode = 'YEM'
			 THEN 1
			 ELSE 2
		END, CCode;
