/*============================================================================
	File:		0040 - correct data types for predicates.sql

	Summary:	This script creates a table with different data types to check
				the execution plan! Although the execution plan is showing a
				SEEK operation it is a SCAN in behind!

	WebLink:	http://db-berater.blogspot.de/2014/05/warum-korrekte-datentypen-fur-where.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL
	DROP TABLE dbo.Customers;
	GO

CREATE TABLE dbo.Customers
(
    Mandant_Id      INT        NOT NULL,
    Customer_Id     CHAR(5)    NOT NULL,
    CustomerName    CHAR(255)  NOT NULL DEFAULT ('Filler'),
);
GO

-- Now we fill the table with sample data
INSERT INTO dbo.Customers
(Mandant_Id, Customer_Id, CustomerName)
SELECT	1		AS	Mandant_Id,
		RIGHT(N'00000' + CAST(Id AS VARCHAR(5)), 5)	AS	Customer_Id,
		name
FROM	CustomerOrders.dbo.Customers;
GO

-- Create a unique clustered index 
CREATE UNIQUE CLUSTERED INDEX ix_Customers_Id ON dbo.Customers
(
	Mandant_Id,
	Customer_Id
);
GO

-- How many pages does the clustered index consume?
SELECT OBJECT_NAME(p.object_id) AS object_name,
       au.type_desc,
       au.data_pages,
       au.used_pages,
       au.total_pages
FROM   sys.allocation_units AS au INNER JOIN sys.partitions AS p
       ON (au.container_id = p.partition_id)
WHERE  p.object_id = OBJECT_ID('dbo.Customers', 'U');
GO

-- Now we do a selection with high cardinality!
SET STATISTICS IO ON;
GO

SELECT *
FROM   dbo.Customers
WHERE  Mandant_Id = 1
       AND Customer_Id = 10489;
GO

SELECT *
FROM   dbo.Customers
WHERE  Mandant_Id = 1
       AND Customer_Id = 10489
OPTION (QUERYTRACEON 9130);
GO


-- do it in the correct way to avoid expensive FILTER operations
SELECT * FROM dbo.Customers
WHERE  Mandant_Id = 1 AND Customer_Id = '10489';
GO

SELECT * FROM dbo.Customers
WHERE  Mandant_Id = CAST(1 AS INT) AND Customer_Id = '10489'
OPTION (QUERYTRACEON 9130);
GO

SET STATISTICS IO OFF
GO

-- clean the kitchen
IF OBJECT_ID('dbo.Customer', 'U') IS NOT NULL
	DROP TABLE dbo.Customers;
	GO
