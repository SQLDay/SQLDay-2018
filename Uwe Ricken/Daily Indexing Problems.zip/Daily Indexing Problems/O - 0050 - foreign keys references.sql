/*============================================================================
	File:		0050 - foreign keys references.sql

	Summary:	This script creates two tables and runs a query against it with
				a JOIN operator. Although only data from one table should be
				retrieved the second table will be touched, too!

	WebLink:	http://db-berater.blogspot.de/2013/12/wie-fremdschlussel-einschrankungen.html

	Date:		Dezember 2014

	SQL Server Version: 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
USE demo_db;
GO

IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL
	DROP TABLE dbo.Customers;
	GO

IF OBJECT_ID('dbo.Invoices', 'U') IS NOT NULL
	DROP TABLE dbo.Invoices;
	GO

CREATE TABLE dbo.Customers
(
	Id		INT				NOT NULL	IDENTITY (1, 1),
	Name	VARCHAR(200)	NOT NULL,
	Street	VARCHAR(100)	NOT NULL,
	ZIP		CHAR(10)		NOT NULL,
	City	VARCHAR(100)	NOT NULL
);

CREATE TABLE dbo.Invoices
(
	Id			INT			NOT NULL	IDENTITY (1, 1),
	Number		CHAR(10)	NOT NULL,
	InvoiceDate	DATE		NOT NULL,
	Customer_Id	INT			NOT NULL,
	Amount		MONEY		NOT NULL
);
GO

/*
	Now we fill both tables with redgate data monitor with sample data
	use Demodata 0050.sqlgen!
*/

-- After filling the tables the necessary indexes will be created
CREATE UNIQUE CLUSTERED INDEX ix_Customers_Id ON dbo.Customers (Id);
CREATE UNIQUE CLUSTERED INDEX ix_Invoices_Id ON dbo.Invoices (Id);
CREATE UNIQUE INDEX ix_Invoices_Number ON dbo.Invoices (Number);
GO

-- Get the customer_id and the sum of all invoices
SET STATISTICS IO ON;
GO

SELECT	I.Customer_Id,
		SUM(I.Amount)	AS	Invoice_Totals
FROM	dbo.Customers AS C INNER JOIN dbo.Invoices AS I
		ON (C.Id = I.Customer_Id)
GROUP BY
		I.Customer_Id;
GO

-- the developer see the desaster and creates an additional index on customer_id
CREATE INDEX ix_Invoices_Customer_Id ON dbo.Invoices (Customer_Id)
INCLUDE (Amount);
GO

-- Get the customer_id and the sum of all invoices
SELECT	I.Customer_Id,
		SUM(I.Amount)	AS	Invoice_Totals
FROM	dbo.Customers AS C INNER JOIN dbo.Invoices AS I
		ON (C.Id = I.Customer_Id)
GROUP BY
		I.Customer_Id;
GO

-- avoid the access to joined tables if they are not needed!
ALTER TABLE dbo.Invoices ADD CONSTRAINT fk_Customers_Id FOREIGN KEY
(Customer_Id) REFERENCES dbo.Customers (Id);
GO

ALTER TABLE dbo.Invoices WITH CHECK CHECK CONSTRAINT fk_Customers_Id;
GO

-- Get the customer_id and the sum of all invoices
SELECT	I.Customer_Id,
		SUM(I.Amount)	AS	Invoice_Totals
FROM	dbo.Customers AS C INNER JOIN dbo.Invoices AS I
		ON (C.Id = I.Customer_Id)
GROUP BY
		I.Customer_Id;
GO

SET STATISTICS IO OFF;
GO

-- clean the kitchen
IF OBJECT_ID('dbo.Invoices', 'U') IS NOT NULL
	DROP TABLE dbo.Invoices;
	GO

IF OBJECT_ID('dbo.Customer', 'U') IS NOT NULL
	DROP TABLE dbo.Customers;
	GO
