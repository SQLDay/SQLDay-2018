/*============================================================================
	File:		0090 - expensive sort spills.sql

	Summary:	This script creates a simple table which can be queried against
				every indexed or non indexed attribute

	WebLink:	none

	Date:		January 2015

	SQL Server Version: 2008 / 2012 / 2014
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE demo_db;
GO

CREATE TABLE dbo.OrderDemo
(
	Id	INT         NOT NULL    IDENTITY (1, 1),
	c1	INT			NOT NULL,
	c2	CHAR(200)	NOT NULL,
	c3	CHAR(200)	NOT NULL,
	c4	CHAR(200)	NOT NULL,
	c5	DATE		NOT NULL
);

/*
	Now we fill both tables with redgate data monitor with sample data
	use Demodata 0090.sqlgen!
*/

CREATE UNIQUE CLUSTERED INDEX uix_OrderDemo_Id ON dbo.OrderDemo (Id);
GO

SET STATISTICS TIME ON;
GO

DECLARE @Id int,
        @c1 int,
        @c2 char(200),
        @c3 char(200),
        @c4 char(200),
        @c5 date
 
-- Abfrage 1: schnell!
SELECT  @Id = Id,
        @c1 = c1,
        @c2 = c2,
        @c3 = c3,
        @c4 = c4,
        @c5 = c5
FROM    dbo.OrderDemo
WHERE   Id <= 9544
ORDER BY c1;
 
-- Abfrage 2: Langsam!
SELECT  @Id = Id,
        @c1 = c1,
        @c2 = c2,
        @c3 = c3,
        @c4 = c4,
        @c5 = c5
FROM    dbo.OrderDemo
WHERE   Id <= 9545
ORDER BY c1;
GO

/* What is the amount of data transferred to the TEMPDB */
DECLARE @Result TABLE
(
	Sequence				INT			NOT NULL	IDENTITY (1, 1),
    Operation				VARCHAR(20)	NOT NULL,
    num_of_reads			BIGINT,
    num_of_bytes_read		BIGINT,
    num_of_writes			BIGINT,
    num_of_bytes_written	BIGINT
);

DECLARE @Id INT,
        @c1 INT,
        @c2 CHAR(200),
        @c3 CHAR(200),
        @c4 CHAR(200),
        @c5 DATE

INSERT INTO @Result
(Operation, num_of_reads, num_of_bytes_read, num_of_writes, num_of_bytes_written)
SELECT  'Intialmessung'              AS Operation,
        SUM(num_of_reads)            AS num_of_reads,
        SUM(num_of_bytes_read)       AS num_of_bytes_read,
        SUM(num_of_writes)           AS num_of_writes,
        SUM(num_of_bytes_written)    AS num_of_bytes_written
FROM    sys.dm_io_virtual_file_stats(db_id('tempdb'), NULL)
WHERE    file_id != 2;
 
SELECT  @Id = Id,
        @c1 = c1,
        @c2 = c2,
        @c3 = c3,
        @c4 = c4,
        @c5 = c5
FROM    dbo.OrderDemo
WHERE   Id <= 9544
ORDER BY c1;

INSERT INTO @Result
(Operation, num_of_reads, num_of_bytes_read, num_of_writes, num_of_bytes_written)
SELECT  'Ausf�hrung <= 9544'        AS Operation,
        SUM(num_of_reads)           AS num_of_reads,
        SUM(num_of_bytes_read)      AS num_of_bytes_read,
        SUM(num_of_writes)          AS num_of_writes,
        SUM(num_of_bytes_written)   AS num_of_bytes_written
FROM    sys.dm_io_virtual_file_stats(db_id('tempdb'), NULL)
WHERE   file_id != 2;
 
SELECT  @Id = Id,
        @c1 = c1,
        @c2 = c2,
        @c3 = c3,
        @c4 = c4,
        @c5 = c5
FROM    dbo.OrderDemo
WHERE   Id <= 9545
ORDER BY c1;
 
INSERT INTO @Result
(Operation, num_of_reads, num_of_bytes_read, num_of_writes, num_of_bytes_written)
SELECT  'Ausf�hrung <= 9545'        AS    Operation,
        SUM(num_of_reads)           AS    num_of_reads,
        SUM(num_of_bytes_read)      AS    num_of_bytes_read,
        SUM(num_of_writes)          AS    num_of_writes,
        SUM(num_of_bytes_written)   AS    num_of_bytes_written
FROM    sys.dm_io_virtual_file_stats(db_id('tempdb'), NULL)
WHERE    file_id != 2;
 
SELECT * FROM @Result;
GO